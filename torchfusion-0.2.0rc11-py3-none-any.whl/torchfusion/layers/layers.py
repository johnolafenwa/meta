import torch.nn as nn
import torch
import torch.nn.functional as F
from torchfusion.initializers import *
from torch.nn.modules.conv import _ConvNd,_pair


class ConvNd(_ConvNd):
    def __init__(self,in_channels,out_channels,kernel_size,stride=1,padding=0,dilation=1,groups=1,bias=True,weight_init=Kaiming_Normal(),bias_init=Zeros(),activation=None,spectral_norm=False,spectral_iteration=1):
        super(ConvNd,self).__init__(in_channels,out_channels,_pair(kernel_size),_pair(stride),_pair(padding),_pair(dilation),False,_pair(0),groups,bias)
        self.activation = activation
        self.spectral_norm = spectral_norm
        self.spectral_iter = spectral_iteration
        weight_init(self.weight.data)
        if bias:
            bias_init(self.bias.data)

        if spectral_norm:
            self.register_buffer("u", torch.Tensor(1, out_channels).normal_())

    def __l2normalize(self,v, eps=1e-12):
        return v / (v.norm() + eps)

    @property
    def WEIGHT(self):

        if self.spectral_norm:
            w_ = self.weight.view(self.weight.size(0), -1)

            for i in range(self.spectral_iter):
                _v = self.__l2normalize(torch.matmul(self.u, w_.data))
                _u = self.__l2normalize(torch.matmul(_v, w_.data.transpose(0, 1)))

            sigma = torch.sum(F.linear(_u, w_.data.transpose(0, 1)) * _v)

            self.u.copy_(_u)
            return self.weight / sigma
        else:
            return self.weight

    def __call__(self, *args, **kwargs):
        outputs = super(ConvNd,self).__call__(*args,**kwargs)
        if self.activation is not None:
            outputs = self.activation(outputs)

        return outputs

class ConvTransposeNd(_ConvNd):
    def __init__(self, in_channels, out_channels, kernel_size, stride=1, padding=0, dilation=1, groups=1, bias=True,
                 weight_init=Kaiming_Normal(), bias_init=Zeros(), activation=None,spectral_norm=False,spectral_iteration=1):
        super(ConvTransposeNd, self).__init__(in_channels, out_channels, _pair(kernel_size), _pair(stride), _pair(padding),
                                     _pair(dilation), True, _pair(0), groups, bias)
        self.activation = activation
        self.spectral_norm = spectral_norm
        self.spectral_iter = spectral_iteration
        weight_init(self.weight.data)
        if bias:
            bias_init(self.bias.data)

        if spectral_norm:
            self.register_buffer("u", torch.Tensor(1, out_channels).normal_())

    def __l2normalize(self, v, eps=1e-12):
        return v / (v.norm() + eps)

    @property
    def WEIGHT(self):

        if self.spectral_norm:
            w_ = self.weight.view(self.weight.size(0), -1)

            for i in range(self.spectral_iter):
                _v = self.__l2normalize(torch.matmul(self.u, w_.data))
                _u = self.__l2normalize(torch.matmul(_v, w_.data.transpose(0, 1)))

            sigma = torch.sum(F.linear(_u, w_.data.transpose(0, 1)) * _v)

            self.u.copy_(_u)
            return self.weight / sigma

        else:
            return self.weight

    def __call__(self, *args, **kwargs):

        outputs = super(ConvTransposeNd,self).__call__(*args, **kwargs)
        if self.activation is not None:
            outputs = self.activation(outputs)

        return outputs

class Conv2d(ConvNd):
    def __init__(self,in_channels,out_channels,kernel_size,stride=1,padding=0,dilation=1,groups=1,bias=True,weight_init=Kaiming_Normal(),bias_init=Zeros(),activation=None,spectral_norm=False,spectral_iteration=1):
        super(Conv2d,self).__init__(in_channels,out_channels,kernel_size,stride,padding,dilation,groups,bias,weight_init,bias_init,activation,spectral_norm,spectral_iteration)


    def forward(self,input):
        return F.conv2d(input,self.WEIGHT,self.bias,self.stride,self.padding,self.dilation,self.groups)


class ConvTranspose2d(ConvTransposeNd):
    def __init__(self,in_channels,out_channels,kernel_size,stride=1,padding=0,dilation=1,groups=1,bias=True,weight_init=Kaiming_Normal(),bias_init=Zeros(),activation=None,spectral_norm=False,spectral_iteration=1):
        super(ConvTranspose2d,self).__init__(in_channels,out_channels,kernel_size,stride,padding,dilation,groups,bias,weight_init,bias_init,activation,spectral_norm,spectral_iteration)


    def forward(self,input):
        return F.conv_transpose2d(input,self.WEIGHT,self.bias,self.stride,self.padding,self.dilation,self.groups)



class Conv1d(ConvNd):
    def __init__(self,in_channels,out_channels,kernel_size,stride=1,padding=0,dilation=1,groups=1,bias=True,weight_init=Kaiming_Normal(),bias_init=Zeros(),activation=None,spectral_norm=False,spectral_iteration=1):
        super(Conv1d,self).__init__(in_channels,out_channels,kernel_size,stride,padding,dilation,groups,bias,weight_init,bias_init,activation,spectral_norm,spectral_iteration)


    def forward(self,input):
        return F.conv1d(input,self.WEIGHT,self.bias,self.stride,self.padding,self.dilation,self.groups)


class ConvTranspose1d(ConvTransposeNd):
    def __init__(self,in_channels,out_channels,kernel_size,stride=1,padding=0,dilation=1,groups=1,bias=True,weight_init=Kaiming_Normal(),bias_init=Zeros(),activation=None,spectral_norm=False,spectral_iteration=1):
        super(ConvTranspose1d,self).__init__(in_channels,out_channels,kernel_size,stride,padding,dilation,groups,bias,weight_init,bias_init,activation,spectral_norm,spectral_iteration)


    def forward(self,input):
        return F.conv_transpose1d(input,self.WEIGHT,self.bias,self.stride,self.padding,self.dilation,self.groups)


class Conv3d(ConvNd):
    def __init__(self,in_channels,out_channels,kernel_size,stride=1,padding=0,dilation=1,groups=1,bias=True,weight_init=Kaiming_Normal(),bias_init=Zeros(),activation=None,spectral_norm=False,spectral_iteration=1):
        super(Conv3d,self).__init__(in_channels,out_channels,kernel_size,stride,padding,dilation,groups,bias,weight_init,bias_init,activation,spectral_norm,spectral_iteration)


    def forward(self,input):
        return F.conv3d(input,self.WEIGHT,self.bias,self.stride,self.padding,self.dilation,self.groups)


class ConvTranspose3d(ConvTransposeNd):
    def __init__(self,in_channels,out_channels,kernel_size,stride=1,padding=0,dilation=1,groups=1,bias=True,weight_init=Kaiming_Normal(),bias_init=Zeros(),activation=None,spectral_norm=False,spectral_iteration=1):
        super(ConvTranspose3d,self).__init__(in_channels,out_channels,kernel_size,stride,padding,dilation,groups,bias,weight_init,bias_init,activation,spectral_norm,spectral_iteration)


    def forward(self,input):
        return F.conv_transpose3d(input,self.WEIGHT,self.bias,self.stride,self.padding,self.dilation,self.groups)



class DepthwiseConv2d(ConvNd):
    def __init__(self,in_channels,kernel_size,stride=1,padding=0,dilation=1,bias=True,weight_init=Kaiming_Normal(),bias_init=Zeros(),activation=None,spectral_norm=False,spectral_iteration=1):
        super(DepthwiseConv2d,self).__init__(in_channels,in_channels,kernel_size,stride,padding,dilation,in_channels,bias,weight_init,bias_init,activation,spectral_norm,spectral_iteration)


    def forward(self,input):
        return F.conv2d(input,self.WEIGHT,self.bias,self.stride,self.padding,self.dilation,self.groups)

class DepthwiseConvTranspose2d(ConvTransposeNd):
    def __init__(self,in_channels,kernel_size,stride=1,padding=0,dilation=1,bias=True,weight_init=Kaiming_Normal(),bias_init=Zeros(),activation=None,spectral_norm=False,spectral_iteration=1):
        super(DepthwiseConvTranspose2d,self).__init__(in_channels,in_channels,kernel_size,stride,padding,dilation,in_channels,bias,weight_init,bias_init,activation,spectral_norm,spectral_iteration)


    def forward(self,input):
        return F.conv_transpose2d(input,self.WEIGHT,self.bias,self.stride,self.padding,self.dilation,self.groups)

class DepthwiseConv1d(ConvNd):
    def __init__(self,in_channels,kernel_size,stride=1,padding=0,dilation=1,bias=True,weight_init=Kaiming_Normal(),bias_init=Zeros(),activation=None,spectral_norm=False,spectral_iteration=1):
        super(DepthwiseConv1d,self).__init__(in_channels,in_channels,kernel_size,stride,padding,dilation,in_channels,bias,weight_init,bias_init,activation,spectral_norm,spectral_iteration)


    def forward(self,input):
        return F.conv1d(input,self.WEIGHT,self.bias,self.stride,self.padding,self.dilation,self.groups)

class DepthwiseConvTranspose1d(ConvTransposeNd):
    def __init__(self,in_channels,kernel_size,stride=1,padding=0,dilation=1,bias=True,weight_init=Kaiming_Normal(),bias_init=Zeros(),activation=None,spectral_norm=False,spectral_iteration=1):
        super(DepthwiseConvTranspose1d,self).__init__(in_channels,in_channels,kernel_size,stride,padding,dilation,in_channels,bias,weight_init,bias_init,activation,spectral_norm,spectral_iteration)


    def forward(self,input):
        return F.conv_transpose1d(input,self.WEIGHT,self.bias,self.stride,self.padding,self.dilation,self.groups)

class DepthwiseConv3d(ConvNd):
    def __init__(self,in_channels,kernel_size,stride=1,padding=0,dilation=1,bias=True,weight_init=Kaiming_Normal(),bias_init=Zeros(),activation=None,spectral_norm=False,spectral_iteration=1):
        super(DepthwiseConv3d,self).__init__(in_channels,in_channels,kernel_size,stride,padding,dilation,in_channels,bias,weight_init,bias_init,activation,spectral_norm,spectral_iteration)


    def forward(self,input):
        return F.conv3d(input,self.WEIGHT,self.bias,self.stride,self.padding,self.dilation,self.groups)

class DepthwiseConvTranspose3d(ConvTransposeNd):
    def __init__(self,in_channels,kernel_size,stride=1,padding=0,dilation=1,bias=True,weight_init=Kaiming_Normal(),bias_init=Zeros(),activation=None,spectral_norm=False,spectral_iteration=1):
        super(DepthwiseConvTranspose3d,self).__init__(in_channels,in_channels,kernel_size,stride,padding,dilation,in_channels,bias,weight_init,bias_init,activation,spectral_norm,spectral_iteration)


    def forward(self,input):
        return F.conv_transpose3d(input,self.WEIGHT,self.bias,self.stride,self.padding,self.dilation,self.groups)


class Linear(nn.Linear):
    def __init__(self,in_features,out_features,bias=True,weight_init=Kaiming_Normal(),bias_init=Zeros(),activation=None,spectral_norm=False,spectral_iteration=1):
        super(Linear,self).__init__(in_features,out_features,bias)
        self.activation = activation
        self.spectral_norm = spectral_norm
        self.spectral_iter = spectral_iteration
        weight_init(self.weight.data)
        if bias:
            bias_init(self.bias.data)

        if spectral_norm:
            self.register_buffer("u", torch.Tensor(1, out_features).normal_())

    def __l2normalize(self,v, eps=1e-12):
        return v / (v.norm() + eps)

    @property
    def WEIGHT(self):

        if self.spectral_norm:
            w_ = self.weight.view(self.weight.size(0), -1)

            for i in range(self.spectral_iter):
                _v = self.__l2normalize(torch.matmul(self.u, w_.data))
                _u = self.__l2normalize(torch.matmul(_v, w_.data.transpose(0, 1)))

            sigma = torch.sum(F.linear(_u, w_.data.transpose(0, 1)) * _v)

            self.u.copy_(_u)
            return self.weight / sigma
        else:
            return self.weight

    def forward(self,input):

        output = F.linear(input,self.WEIGHT,self.bias)

        if self.activation is not None:
            output = self.activation(output)

        return output

class Flatten(nn.Module):
    def __init__(self):
        super(Flatten,self).__init__()

    def forward(self,inputs):
        size = torch.prod(torch.LongTensor(list(inputs.size())[1:])).item()

        return inputs.view((-1,size))

class Reshape(nn.Module):
    def __init__(self,output_shape):
        super(Reshape,self).__init__()

        self.output_shape = output_shape

    def forward(self,inputs):
        if isinstance(self.output_shape,int):
            size = [self.output_shape]
        else:
            size = list(self.output_shape)

        input_total_size = torch.prod(torch.LongTensor(list(inputs.size())[1:])).item()
        target_total_size = torch.prod(torch.LongTensor(size)).item()

        if input_total_size != target_total_size:
            raise ValueError(" Reshape must preserve total dimension, input size: {} and output size: {}".format(input.size()[1:],self.output_shape))

        size = list(size)
        size = tuple([-1] + size)
        outputs = inputs.view(size)

        return outputs


class GlobalAvgPool2d(nn.Module):
    def __init__(self):
        super(GlobalAvgPool2d,self).__init__()


    def forward(self,inputs):
        size0, size1,size2 = inputs.size(1), inputs.size(2),inputs.size(3)

        outputs = nn.AvgPool2d((size1,size2))(inputs).view(-1,size0)

        return outputs

class GlobalMaxPool2d(nn.Module):
    def __init__(self):
        super(GlobalMaxPool2d,self).__init__()


    def forward(self,inputs):
        size0, size1,size2 = inputs.size(1), inputs.size(2),inputs.size(3)

        outputs = nn.MaxPool2d((size1,size2))(inputs).view(-1,size0)

        return outputs



class GlobalAvgPool1d(nn.Module):
    def __init__(self):
        super(GlobalAvgPool1d,self).__init__()


    def forward(self,inputs):
        size0, size1 = inputs.size(1), inputs.size(2)

        outputs = nn.AvgPool1d(size1)(inputs).view(-1,size0)

        return outputs


class GlobalMaxPool1d(nn.Module):
    def __init__(self):
        super(GlobalMaxPool1d, self).__init__()

    def forward(self, inputs):
        size0, size1 = inputs.size(1), inputs.size(2)

        outputs = nn.MaxPool1d(size1)(inputs).view(-1, size0)

        return outputs


class SelfAttention(nn.Module):
    def __init__(self,in_channels,weight_init,bias_init,use_bias):
        super(SelfAttention,self).__init__()

        self.q = nn.Conv2d(in_channels,in_channels//8,kernel_size=1)
        self.k = nn.Conv2d(in_channels,in_channels//8,kernel_size=1)

        self.v = nn.Conv2d(in_channels,in_channels,kernel_size=1)

        self.softmax = nn.Softmax(dim=-1)

        self.atten_weight = nn.Parameter(torch.tensor([0.0]))

    def forward(self,input):
        batch_size, channels, width, height = input.size()
        res = input

        queries = self.q(input).view(batch_size,-1,width*height).permute(0,2,1)
        keys = self.k(input).view(batch_size,-1,width*height)
        values = self.v(input).view(batch_size, -1, width * height)

        atten_ = self.softmax(torch.bmm(queries, keys)).permute(0,2,1)

        atten_values = torch.bmm(values,atten_).view(batch_size,channels,width,height)


        return (self.atten_weight * atten_values) + res


class Swish(nn.Module):
    def __init__(self):
        super(Swish, self).__init__()

    def forward(self, inputs):

        return inputs * F.sigmoid(inputs)

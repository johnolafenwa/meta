import torch.nn as nn
import torch
import functools
from torchvision.datasets import svhn
from ...layers import *
from .layers import *
from torchfusion.initializers import *


class ResnetGenerator(nn.Module):
    def __init__(self,output_size,num_classes=10,latent_size=100,kernel_size=3,activation=nn.ReLU()):
        super().__init__()

        output_channels = output_size[0]
        self.size = output_size[1]

        self.fc = Linear(latent_size,4 * 4 * self.size * 8)

        current_size = 4

        layers = []

        in_channels = self.size * 8

        while current_size < self.size:
            layers.append(GeneratorResBlock(in_channels,in_channels // 2,num_classes,upsample_size=2,kernel_size=kernel_size,activation=activation))
            current_size *= 2

            if current_size < self.size:
                in_channels /= 2

        layers.append(BatchNorm2d(in_channels,weight_init=Normal(1.0,0.02)))
        layers.append(Conv2d(in_channels,output_channels,kernel_size=3,padding=1,weight_init=Xavier_Uniform()))

        self.net = nn.Sequential(*layers)

    def forward(self,inputs,labels):
        outputs = self.fc(inputs).view(-1,self.size * 8,4,4)
        outputs = self.net(outputs)

        return outputs



""" The standard DCGAN Generator as proposed by Radford et al. 2015 (https://arxiv.org/1511.06434)
    latent_size: the size of the noise vector
    output_size: the size of the image to be generated
    dropout_ratio: Dropout rate for applying dropout after every Relu layer
    use_bias: Enables or disables bias in the convolution layers
    num_gpus: Parallelizes computation over the number of GPUs specified.

"""
class DCGANGenerator(nn.Module):
    def __init__(self,latent_size,output_size,dropout_ratio=0.0,use_bias=False,num_gpus=1):
        super(DCGANGenerator,self).__init__()

        assert output_size[1] >= 32

        self.num_gpus = num_gpus

        in_channels = latent_size[0]

        multiplier = 8
        out_size = output_size[1]
        layers = [nn.ConvTranspose2d(in_channels=in_channels,out_channels=int(out_size * multiplier),kernel_size=4,stride=1,padding=0,bias=use_bias),
                  nn.BatchNorm2d(int(out_size * multiplier)),
                  nn.ReLU(inplace=True),
                  nn.Dropout(dropout_ratio)
                  ]

        in_channels = int(out_size * multiplier)

        size = 4 * latent_size[1]
        while size < output_size[1]:
            multiplier /= 2
            size *= 2

            if size < int(out_size * multiplier):
                out_channels = int(out_size * multiplier)
            else:
                out_channels = out_size
            if size == output_size[1]:
                layers.append(nn.ConvTranspose2d(in_channels=in_channels, out_channels=output_size[0], kernel_size=4, stride=2, padding=1, bias=use_bias))
                layers.append(nn.Tanh())
            else:
                layers.append(nn.ConvTranspose2d(in_channels=in_channels, out_channels=out_channels, kernel_size=4, stride=2, padding=1, bias=use_bias))
                layers.append(nn.BatchNorm2d(out_channels))
                layers.append(nn.ReLU(inplace=True))
                layers.append(nn.Dropout(dropout_ratio))
                in_channels = out_channels

        self.net = nn.Sequential(*layers)

    def forward(self,inputs):

        if inputs.is_cuda and self.num_gpus > 1:
            out = nn.parallel.data_parallel(self.net,inputs,range(self.num_gpus))
        else:
            out = self.net(inputs)

        return out


""" The standard DCGAN Discriminator as proposed by Radford et al. 2015 (https://arxiv.org/1511.06434)
    input_size: the size of the input image
    dropout_ratio: Dropout rate for applying dropout after every Relu layer
    use_bias: Enables or disables bias in the convolution layers
    num_gpus: Parallelizes computation over the number of GPUs specified.

"""
class DCGANDiscriminator(nn.Module):
    def __init__(self,input_size,dropout_ratio=0.0,use_bias=False,num_gpus=1):
        super(DCGANDiscriminator,self).__init__()

        assert input_size[1] >= 32

        self.num_gpus = num_gpus

        input_channels = input_size[0]
        in_channels = input_channels
        size = input_size[1]

        channel_multiplier = 1

        out_channels = size

        layers = []

        while size > 4:
            layers.append(nn.Conv2d(in_channels=in_channels,out_channels=out_channels,kernel_size=4,stride=2,padding=1,bias=use_bias))
            if size != input_size[1]:
                layers.append(nn.BatchNorm2d(out_channels))
            layers.append(nn.LeakyReLU(0.2,inplace=True))
            layers.append(nn.Dropout(dropout_ratio))
            if channel_multiplier < 8:
                channel_multiplier *= 2
            size /= 2


            in_channels = out_channels
            out_channels = input_size[1] * channel_multiplier

        layers.append(nn.Conv2d(in_channels=in_channels,out_channels=1,kernel_size=4,padding=0,bias=use_bias))
        layers.append(nn.Sigmoid())

        self.net = nn.Sequential(*layers)


    def forward(self,input):

        if input.is_cuda and self.num_gpus > 1:
            output = nn.parallel.data_parallel(self.net,input,range(self.num_gpus))
        else:
            output = self.net(input)

        return output.view(-1,1).squeeze(1)


""" The standard DCGAN Discriminator as proposed by Radford et al. 2015 (https://arxiv.org/1511.06434)
    input_size: the size of the input image
    dropout_ratio: Dropout rate for applying dropout after every Relu layer
    use_bias: Enables or disables bias in the convolution layers
    num_gpus: Parallelizes computation over the number of GPUs specified.

"""
class AuxDCGANDiscriminator(nn.Module):
    def __init__(self,input_size,num_classes,dropout_ratio=0.0,use_bias=False,num_gpus=1):
        super(AuxDCGANDiscriminator,self).__init__()

        assert input_size[1] >= 32

        self.num_gpus = num_gpus

        input_channels = input_size[0]
        in_channels = input_channels
        size = input_size[1]

        channel_multiplier = 1

        out_channels = size

        layers = []

        while size > 4:
            layers.append(nn.Conv2d(in_channels=in_channels,out_channels=out_channels,kernel_size=4,stride=2,padding=1,bias=use_bias))
            if size != input_size[1]:
                layers.append(nn.BatchNorm2d(out_channels))
            layers.append(nn.LeakyReLU(0.2,inplace=True))
            layers.append(nn.Dropout(dropout_ratio))
            if channel_multiplier < 8:
                channel_multiplier *= 2
            size /= 2


            in_channels = out_channels
            out_channels = input_size[1] * channel_multiplier

        layers.append(nn.Conv2d(in_channels=in_channels,out_channels=num_classes,kernel_size=4,padding=0,bias=use_bias))

        self.net = nn.Sequential(*layers)


    def forward(self,input):

        if input.is_cuda and self.num_gpus > 1:
            output = nn.parallel.data_parallel(self.net,input,range(self.num_gpus))
        else:
            output = self.net(input)

        return output.view(-1,1).squeeze(1)



""" Wasserstein DCGAN Discriminator as proposed by Gulrajani et al. 2017 (https://arxiv.org/1704.00028)
    based on earlier work by Arjovsky et al. 2017 (https://arxiv.org/1701.07875)
   
    input_size: the size of the input image
    dropout_ratio: Dropout rate for applying dropout after every Relu layer
    use_bias: Enables or disables bias in the convolution layers
    num_gpus: Parallelizes computation over the number of GPUs specified.

"""
class WGANDiscriminator(nn.Module):
    def __init__(self,input_size,dropout_ratio=0.0,use_bias=False,num_gpus=1):
        super(WGANDiscriminator,self).__init__()

        assert input_size[1] >= 32

        self.num_gpus = num_gpus

        input_channels = input_size[0]
        in_channels = input_channels
        size = input_size[1]

        channel_multiplier = 1

        out_channels = size

        layers = []

        while size > 4:
            layers.append(nn.Conv2d(in_channels=in_channels,out_channels=out_channels,kernel_size=4,stride=2,padding=1,bias=use_bias))
            layers.append(nn.LeakyReLU(0.2,inplace=True))
            layers.append(nn.Dropout(dropout_ratio))
            if channel_multiplier < 8:
                channel_multiplier *= 2
            size /= 2


            in_channels = out_channels
            out_channels = input_size[1] * channel_multiplier

        layers.append(nn.Conv2d(in_channels=in_channels,out_channels=1,kernel_size=4,padding=0,bias=use_bias))

        self.net = nn.Sequential(*layers)


    def forward(self,input):

        if input.is_cuda and self.num_gpus > 1:
            output = nn.parallel.data_parallel(self.net,input,range(self.num_gpus))
        else:
            output = self.net(input)

        return output.view(-1,1).squeeze(1)

class MLPGenerator(nn.Module):
    def __init__(self,latent_size,output_size,hidden_dims=512,depth=4,dropout_ratio=0.0,num_gpus=1):
        super(MLPGenerator,self).__init__()
        self.num_gpus = num_gpus
        self.output_size = output_size

        layers = []
        layers.append(nn.Linear(latent_size, hidden_dims))
        layers.append(nn.LeakyReLU(0.2))
        layers.append(nn.Dropout(dropout_ratio))

        for i in range(depth - 2):
            layers.append(nn.Linear(hidden_dims, hidden_dims))
            layers.append(nn.LeakyReLU(0.2))
            layers.append(nn.Dropout(dropout_ratio))

        layers.append(nn.Linear(hidden_dims,output_size[0]*output_size[1] * output_size[2]))
        layers.append(nn.Tanh())
        self.net = nn.Sequential(*layers)

    def forward(self,input):
        if input.is_cuda and self.num_gpus > 1:
            output = nn.parallel.data_parallel(self.net,input,range(self.num_gpus))
        else:
            output = self.net(input)

        return output.view(-1,self.output_size[0],self.output_size[1] ,self.output_size[2])

class MLPDiscriminator(nn.Module):
    def __init__(self,input_size,hidden_dims=512,depth=4,dropout_ratio=0.0,num_gpus=1):
        super(MLPDiscriminator,self).__init__()
        self.num_gpus = num_gpus
        self.input_size = input_size

        layers = []
        layers.append(nn.Linear(input_size[0] * input_size[1] * input_size[2], hidden_dims))
        layers.append(nn.LeakyReLU(0.2))
        layers.append(nn.Dropout(dropout_ratio))

        for i in range(depth - 2):
            layers.append(nn.Linear(hidden_dims, hidden_dims))
            layers.append(nn.LeakyReLU(0.2))
            layers.append(nn.Dropout(dropout_ratio))

        layers.append(nn.Linear(hidden_dims, 1))
        layers.append(nn.Sigmoid())

        self.net = nn.Sequential(*layers)
    def forward(self,input):
        input = input.view(-1,input.size(1) * input.size(2) * input.size(3))
        if input.is_cuda and self.num_gpus > 1:
            output = nn.parallel.data_parallel(self.net,input,range(self.num_gpus))
        else:
            output = self.net(input)

        return output.view(-1, 1).squeeze(1)

class WMLPDiscriminator(nn.Module):
    def __init__(self,input_size,hidden_dims=512,depth=4,dropout_ratio=0.0,num_gpus=1):
        super(WMLPDiscriminator,self).__init__()
        self.num_gpus = num_gpus
        self.input_size = input_size

        layers = []
        layers.append(nn.Linear(input_size[0] * input_size[1] * input_size[2],hidden_dims))
        layers.append(nn.LeakyReLU(0.2))
        layers.append(nn.Dropout(dropout_ratio))

        for i in range(depth - 2):
            layers.append(nn.Linear(hidden_dims,hidden_dims))
            layers.append(nn.LeakyReLU(0.2))
            layers.append(nn.Dropout(dropout_ratio))

        layers.append(nn.Linear(hidden_dims,1))

        self.net = nn.Sequential(*layers)

    def forward(self,input):
        input = input.view(-1,input.size(1) * input.size(2) * input.size(3))
        if input.is_cuda and self.num_gpus > 1:
            output = nn.parallel.data_parallel(self.net,input,range(self.num_gpus))
        else:
            output = self.net(input)

        return output.view(-1, 1).squeeze(1)



class UnetEncoderBlock(nn.Module):
    def __init__(self,in_channels,out_channels,use_bn=True,dropout_ratio=0.0):
        super(UnetEncoderBlock,self).__init__()

        layers = [nn.Conv2d(in_channels,out_channels,kernel_size=4,stride=2,padding=1,bias=False)]
        if use_bn:
            layers.append(nn.BatchNorm2d(out_channels))
        layers.append(nn.LeakyReLU(0.2,True))

        if dropout_ratio > 0.0:
            layers.append(nn.Dropout(dropout_ratio))

        self.net = nn.Sequential(*layers)

    def forward(self,inputs):
        outputs = self.net(inputs)

        return outputs

class UnetDecoderBlock(nn.Module):
    def __init__(self,in_channels,out_channels,use_bn=True,dropout_ratio=0.0):
        super(UnetDecoderBlock,self).__init__()

        layers = [nn.ConvTranspose2d(in_channels,out_channels,kernel_size=4,stride=2,padding=1,bias=False)]
        if use_bn:
            layers.append(nn.BatchNorm2d(out_channels))
        layers.append(nn.LeakyReLU(0.2,True))

        if dropout_ratio > 0.0:
            layers.append(nn.Dropout(dropout_ratio))

        self.net = nn.Sequential(*layers)

    def forward(self,inputs):
        outputs = self.net(inputs)

        return outputs

class UnetGenerator(nn.Module):
    def __init__(self, input_nc, output_nc, num_downs, ngf=64,
                 norm_layer=nn.BatchNorm2d, use_dropout=False):
        super(UnetGenerator, self).__init__()

        # construct unet structure
        unet_block = UnetSkipConnectionBlock(ngf * 8, ngf * 8, input_nc=None, submodule=None, norm_layer=norm_layer, innermost=True)
        for i in range(num_downs - 5):
            unet_block = UnetSkipConnectionBlock(ngf * 8, ngf * 8, input_nc=None, submodule=unet_block, norm_layer=norm_layer, use_dropout=use_dropout)
        unet_block = UnetSkipConnectionBlock(ngf * 4, ngf * 8, input_nc=None, submodule=unet_block, norm_layer=norm_layer)
        unet_block = UnetSkipConnectionBlock(ngf * 2, ngf * 4, input_nc=None, submodule=unet_block, norm_layer=norm_layer)
        unet_block = UnetSkipConnectionBlock(ngf, ngf * 2, input_nc=None, submodule=unet_block, norm_layer=norm_layer)
        unet_block = UnetSkipConnectionBlock(output_nc, ngf, input_nc=input_nc, submodule=unet_block, outermost=True, norm_layer=norm_layer)

        self.model = unet_block

    def forward(self, input):
        return self.model(input)


# Defines the submodule with skip connection.
# X -------------------identity---------------------- X
#   |-- downsampling -- |submodule| -- upsampling --|
class UnetSkipConnectionBlock(nn.Module):
    def __init__(self, outer_nc, inner_nc, input_nc=None,
                 submodule=None, outermost=False, innermost=False, norm_layer=nn.BatchNorm2d, use_dropout=False):
        super(UnetSkipConnectionBlock, self).__init__()
        self.outermost = outermost
        if type(norm_layer) == functools.partial:
            use_bias = norm_layer.func == nn.InstanceNorm2d
        else:
            use_bias = norm_layer == nn.InstanceNorm2d
        if input_nc is None:
            input_nc = outer_nc
        downconv = nn.Conv2d(input_nc, inner_nc, kernel_size=4,
                             stride=2, padding=1, bias=use_bias)
        downrelu = nn.LeakyReLU(0.2, True)
        downnorm = norm_layer(inner_nc)
        uprelu = nn.ReLU(True)
        upnorm = norm_layer(outer_nc)

        if outermost:
            upconv = nn.ConvTranspose2d(inner_nc * 2, outer_nc,
                                        kernel_size=4, stride=2,
                                        padding=1)
            down = [downconv]
            up = [uprelu, upconv, nn.Tanh()]
            model = down + [submodule] + up
        elif innermost:
            upconv = nn.ConvTranspose2d(inner_nc, outer_nc,
                                        kernel_size=4, stride=2,
                                        padding=1, bias=use_bias)
            down = [downrelu, downconv]
            up = [uprelu, upconv, upnorm]
            model = down + up
        else:
            upconv = nn.ConvTranspose2d(inner_nc * 2, outer_nc,
                                        kernel_size=4, stride=2,
                                        padding=1, bias=use_bias)
            down = [downrelu, downconv, downnorm]
            up = [uprelu, upconv, upnorm]

            if use_dropout:
                model = down + [submodule] + up + [nn.Dropout(0.5)]
            else:
                model = down + [submodule] + up

        self.model = nn.Sequential(*model)

    def forward(self, x):
        if self.outermost:
            return self.model(x)
        else:
            return torch.cat([x, self.model(x)], 1)

class UnetGenerator1(nn.Module):
    def __init__(self,in_channels,output_size,dropout_ratio=0.0):
        super(UnetGenerator1,self).__init__()

        encoder_layers = []

        decoder_layers = []

        size = output_size[1]
        channels_in = in_channels
        channels_out = 64
        use_bn = False
        while size > 1:

            encoder_layers.append(UnetEncoderBlock(channels_in,channels_out,use_bn=use_bn,dropout_ratio=dropout_ratio))
            channels_in = channels_out
            use_bn = True

            if channels_out < 512:
                channels_out *= 2
            size /= 2

        self.enc_modules = nn.ModuleList(self.encoder_layers)


        channels_out = 64

        while size < output_size[1]:
            size *= 2

            if size == output_size[1]:
                pass


            else:
                decoder_layers.append(UnetDecoderBlock(channels_in, channels_out, use_bn=True, dropout_ratio=dropout_ratio))
                channels_in = channels_out


            if channels_out < 512:
                channels_out /= 2




    def forward(self,inputs):

        #outputs = self.enc_net(inputs)

        return 1


# Defines the PatchGAN discriminator with the specified arguments.
class NLayerDiscriminator(nn.Module):
    def __init__(self, input_nc, ndf=64, n_layers=3, norm_layer=nn.BatchNorm2d, use_sigmoid=False):
        super(NLayerDiscriminator, self).__init__()
        if type(norm_layer) == functools.partial:
            use_bias = norm_layer.func == nn.InstanceNorm2d
        else:
            use_bias = norm_layer == nn.InstanceNorm2d

        kw = 4
        padw = 1
        sequence = [
            nn.Conv2d(input_nc, ndf, kernel_size=kw, stride=2, padding=padw),
            nn.LeakyReLU(0.2, True)
        ]

        nf_mult = 1
        nf_mult_prev = 1
        for n in range(1, n_layers):
            nf_mult_prev = nf_mult
            nf_mult = min(2**n, 8)
            sequence += [
                nn.Conv2d(ndf * nf_mult_prev, ndf * nf_mult,
                          kernel_size=kw, stride=2, padding=padw, bias=use_bias),
                norm_layer(ndf * nf_mult),
                nn.LeakyReLU(0.2, True)
            ]

        nf_mult_prev = nf_mult
        nf_mult = min(2**n_layers, 8)
        sequence += [
            nn.Conv2d(ndf * nf_mult_prev, ndf * nf_mult,
                      kernel_size=kw, stride=1, padding=padw, bias=use_bias),
            norm_layer(ndf * nf_mult),
            nn.LeakyReLU(0.2, True)
        ]

        sequence += [nn.Conv2d(ndf * nf_mult, 1, kernel_size=kw, stride=1, padding=padw)]

        if use_sigmoid:
            sequence += [nn.Sigmoid()]

        self.model = nn.Sequential(*sequence)

    def forward(self, input):
        return self.model(input)


class PixelDiscriminator(nn.Module):
    def __init__(self, input_nc, ndf=64, norm_layer=nn.BatchNorm2d, use_sigmoid=False):
        super(PixelDiscriminator, self).__init__()
        if type(norm_layer) == functools.partial:
            use_bias = norm_layer.func == nn.InstanceNorm2d
        else:
            use_bias = norm_layer == nn.InstanceNorm2d

        self.net = [
            nn.Conv2d(input_nc, ndf, kernel_size=1, stride=1, padding=0),
            nn.LeakyReLU(0.2, True),
            nn.Conv2d(ndf, ndf * 2, kernel_size=1, stride=1, padding=0, bias=use_bias),
            norm_layer(ndf * 2),
            nn.LeakyReLU(0.2, True),
            nn.Conv2d(ndf * 2, 1, kernel_size=1, stride=1, padding=0, bias=use_bias)]

        if use_sigmoid:
            self.net.append(nn.Sigmoid())

        self.net = nn.Sequential(*self.net)

    def forward(self, input):
        return self.net(input)
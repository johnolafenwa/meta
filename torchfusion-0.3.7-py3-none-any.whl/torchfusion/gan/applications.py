import torch.nn as nn
import torch


class DCGANGenerator(nn.Module):
    def __init__(self,input_size,output_channels=3,output_size=64,dropout_ratio=0.0,use_bias=False,num_gpus=1):
        super(DCGANGenerator,self).__init__()

        if output_size % 8 != 0:
            raise ValueError("Output size {} is invalid, should be a multiple  of 8".format(output_size))

        self.num_gpus = num_gpus

        in_channels = input_size[0]

        channel_multiplier = output_size//8
        out_channels = int(output_size * channel_multiplier)
        layers = [nn.ConvTranspose2d(in_channels=in_channels,out_channels=out_channels,kernel_size=4,stride=1,padding=0,bias=use_bias),
                  nn.BatchNorm2d(out_channels),
                  nn.ReLU(inplace=True),
                  nn.Dropout(dropout_ratio)
                  ]

        in_channels = out_channels

        size = 4 * input_size[1]
        while size < output_size:
            channel_multiplier /= 2
            size *= 2

            if size == output_size:
                layers.append(nn.ConvTranspose2d(in_channels=in_channels, out_channels=output_channels, kernel_size=4, stride=2, padding=1, bias=use_bias))
                layers.append(nn.Tanh())
            else:
                layers.append(nn.ConvTranspose2d(in_channels=in_channels, out_channels=out_channels, kernel_size=4, stride=2, padding=1, bias=use_bias))
                layers.append(nn.BatchNorm2d(out_channels))
                layers.append(nn.ReLU(inplace=True))
                layers.append(nn.Dropout(dropout_ratio))
                in_channels = out_channels
                out_channels = int(output_size * channel_multiplier)

        self.net = nn.Sequential(*layers)

    def forward(self,inputs):

        if inputs.is_cuda and self.num_gpus > 1:
            out = nn.parallel.data_parallel(self.net,inputs,range(self.num_gpus))
        else:
            out = self.net(inputs)

        return out


class DCGANDiscriminator(nn.Module):
    def __init__(self,input_size,dropout_ratio=0.0,use_bias=False,num_gpus=1):
        super(DCGANDiscriminator,self).__init__()

        self.num_gpus = num_gpus

        input_channels = input_size[0]
        in_channels = input_channels
        size = input_size[1]

        channel_multiplier = 1

        out_channels = size

        layers = []

        while size > 4:
            layers.append(nn.Conv2d(in_channels=in_channels,out_channels=out_channels,kernel_size=4,stride=2,padding=1,bias=use_bias))
            layers.append(nn.LeakyReLU(0.2,inplace=True))
            layers.append(nn.Dropout(dropout_ratio))
            channel_multiplier += 2
            size /= 2


            in_channels = out_channels
            out_channels = input_channels * channel_multiplier

        layers.append(nn.Conv2d(in_channels=in_channels,out_channels=1,kernel_size=4,padding=0,bias=use_bias))
        layers.append(nn.Sigmoid())

        self.net = nn.Sequential(*layers)


    def forward(self,input):

        if input.is_cuda and self.num_gpus > 1:
            output = nn.parallel.data_parallel(self.net,input,range(self.num_gpus))
        else:
            output = self.net(input)

        return output.view(-1,1).squeeze(1)

class WassersteinDCGANDiscriminator(nn.Module):
    def __init__(self,input_size,dropout_ratio=0.0,use_bias=False,num_gpus=1):
        super(WassersteinDCGANDiscriminator,self).__init__()

        self.num_gpus = num_gpus

        input_channels = input_size[0]
        in_channels = input_channels
        size = input_size[1]

        channel_multiplier = 1

        out_channels = size

        layers = []

        while size > 4:
            layers.append(nn.Conv2d(in_channels=in_channels,out_channels=out_channels,kernel_size=4,stride=2,padding=1,bias=use_bias))
            layers.append(nn.BatchNorm2d(out_channels))
            layers.append(nn.LeakyReLU(0.2,inplace=True))
            layers.append(nn.Dropout(dropout_ratio))
            channel_multiplier += 2
            size /= 2


            in_channels = out_channels
            out_channels = input_channels * channel_multiplier

        layers.append(nn.Conv2d(in_channels=in_channels,out_channels=1,kernel_size=4,padding=0,bias=use_bias))

        self.net = nn.Sequential(*layers)


    def forward(self,input):

        if input.is_cuda and self.num_gpus > 1:
            output = nn.parallel.data_parallel(self.net,input,range(self.num_gpus))
        else:
            output = self.net(input)

        return output.view(-1,1).squeeze(1)

class MLPDiscriminator(nn.Module):
    def __init__(self,input_dim):
        super(MLPDiscriminator, self).__init__()

        self.fc1 = nn.Linear(input_dim, 1024)
        self.act1 = nn.LeakyReLU(0.2)
        self.dropout1 = nn.Dropout(0.3)
        self.fc2 = nn.Linear(1024, 512)
        self.act2 = nn.LeakyReLU(0.2)
        self.dropout2 = nn.Dropout(0.3)
        self.fc3 = nn.Linear(512, 256)
        self.act3 = nn.LeakyReLU(0.2)
        self.dropout3 = nn.Dropout(0.3)
        self.fc = nn.Linear(256, 1)
        self.sigmoid = nn.Sigmoid()

        self.net = nn.Sequential(self.fc1, self.act1,self.dropout1, self.fc2, self.act2,self.dropout2, self.fc3, self.act3,self.dropout3, self.fc)

    def forward(self, input):
        output = self.net(input)
        output = self.sigmoid(output)
        return output

class WassersteinMLPDiscriminator(nn.Module):
    def __init__(self,dropout_ratio=0.2):
        super(WassersteinMLPDiscriminator, self).__init__()

        self.fc1 = nn.Linear(784, 1024)
        self.act1 = nn.LeakyReLU(0.2)
        self.dropout1 = nn.Dropout(dropout_ratio)
        self.fc2 = nn.Linear(1024, 512)
        self.act2 = nn.LeakyReLU(0.2)
        self.dropout2 = nn.Dropout(dropout_ratio)
        self.fc3 = nn.Linear(512, 256)
        self.act3 = nn.LeakyReLU(0.2)
        self.dropout3 = nn.Dropout(dropout_ratio)
        self.fc = nn.Linear(256, 1)
        self.sigmoid = nn.Sigmoid()

        self.net = nn.Sequential(self.fc1, self.act1,self.dropout1, self.fc2, self.act2,self.dropout2, self.fc3, self.act3,self.dropout3, self.fc)

    def forward(self, input):
        output = self.net(input)
        output = self.sigmoid(output)
        return output

class MLPGenerator(nn.Module):
    def __init__(self,output_dim,dropout_ratio=0.0):
        super(MLPGenerator,self).__init__()

        self.fc1 = nn.Linear(100,256)
        self.act1 = nn.LeakyReLU(0.2)
        self.dropout1 = nn.Dropout(dropout_ratio)
        self.fc2 = nn.Linear(256, 512)
        self.act2 = nn.LeakyReLU(0.2)
        self.dropout2 = nn.Dropout(dropout_ratio)
        self.fc3 = nn.Linear(512, 1024)
        self.act3 = nn.LeakyReLU(0.2)
        self.dropout3 = nn.Dropout(dropout_ratio)
        self.fc = nn.Linear(1024,output_dim)

        self.net = nn.Sequential(self.fc1,self.act1,self.dropout1,self.fc2,self.act2,self.dropout2,self.fc3,self.act3,self.dropout3,self.fc)

    def forward(self,input):
        output = self.net(input)
        return output

class MLPGenerator2(nn.Module):
    def __init__(self,latent_size,output_size,dropout_ratio=0.0,num_gpus=1):
        super(MLPGenerator2,self).__init__()
        self.num_gpus = num_gpus
        self.output_size = output_size

        self.latent_size = latent_size

        self.fc1 = nn.Linear(self.latent_size,512)
        self.act1 = nn.LeakyReLU(0.2)
        self.dropout1 = nn.Dropout(dropout_ratio)
        self.fc2 = nn.Linear(512,512)
        self.act2 = nn.LeakyReLU(0.2)
        self.dropout2 = nn.Dropout(dropout_ratio)
        self.fc3 = nn.Linear(512, 512)
        self.act3 = nn.LeakyReLU(0.2)
        self.dropout3 = nn.Dropout(dropout_ratio)
        self.fc = nn.Linear(512,output_size[0]*output_size[1] * output_size[2])

        self.net = nn.Sequential(self.fc1,self.act1,self.dropout1,self.fc2,self.act2,self.dropout2,self.fc3,self.act3,self.dropout3,self.fc)

    def forward(self,input):
        if input.is_cuda and self.num_gpus > 1:
            output = nn.parallel.data_parallel(self.net,input,range(self.num_gpus))
        else:
            output = self.net(input)

        return output.view(-1,self.output_size[0],self.output_size[1] ,self.output_size[2])

class MLPDiscriminator2(nn.Module):
    def __init__(self,input_size,dropout_ratio=0.0,num_gpus=1):
        super(MLPDiscriminator2,self).__init__()
        self.num_gpus = num_gpus
        self.input_size = input_size

        self.fc1 = nn.Linear(input_size[0] * input_size[1] * input_size[2],512)
        self.act1 = nn.LeakyReLU(0.2)
        self.dropout1 = nn.Dropout(dropout_ratio)
        self.fc2 = nn.Linear(512,512)
        self.act2 = nn.LeakyReLU(0.2)
        self.dropout2 = nn.Dropout(dropout_ratio)
        self.fc3 = nn.Linear(512, 512)
        self.act3 = nn.LeakyReLU(0.2)
        self.dropout3 = nn.Dropout(dropout_ratio)
        self.fc = nn.Linear(512,1)

        self.net = nn.Sequential(self.fc1,self.act1,self.dropout1,self.fc2,self.act2,self.dropout2,self.fc3,self.act3,self.dropout3,self.fc,nn.Sigmoid())

    def forward(self,input):
        input = input.view(-1,input.size(1) * input.size(2) * input.size(3))
        if input.is_cuda and self.num_gpus > 1:
            output = nn.parallel.data_parallel(self.net,input,range(self.num_gpus))
        else:
            output = self.net(input)

        return output

class WassersteinMLPDiscriminator2(nn.Module):
    def __init__(self,input_size,dropout_ratio=0.0,num_gpus=1):
        super(WassersteinMLPDiscriminator2,self).__init__()
        self.num_gpus = num_gpus
        self.input_size = input_size

        self.fc1 = nn.Linear(input_size[0] * input_size[1] * input_size[2],512)
        self.act1 = nn.LeakyReLU(0.2)
        self.dropout1 = nn.Dropout(dropout_ratio)
        self.fc2 = nn.Linear(512,512)
        self.act2 = nn.LeakyReLU(0.2)
        self.dropout2 = nn.Dropout(dropout_ratio)
        self.fc3 = nn.Linear(512, 512)
        self.act3 = nn.LeakyReLU(0.2)
        self.dropout3 = nn.Dropout(dropout_ratio)
        self.fc = nn.Linear(512,1)

        self.net = nn.Sequential(self.fc1,self.act1,self.dropout1,self.fc2,self.act2,self.dropout2,self.fc3,self.act3,self.dropout3,self.fc)

    def forward(self,input):
        input = input.view(-1,input.size(1) * input.size(2) * input.size(3))
        if input.is_cuda and self.num_gpus > 1:
            output = nn.parallel.data_parallel(self.net,input,range(self.num_gpus))
        else:
            output = self.net(input)

        return output








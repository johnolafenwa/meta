import matplotlib.pyplot as plt

def adjust_learning_rate(lr,optimizer):
    for param_group in optimizer.param_groups:
        param_group["lr"] = lr


def visualize_metrics(y, x,save_metric=None):

    num_metrics = len(x)
    plt.figure(1)
    for i,(values,name,color) in enumerate(x):
        print(values,name,color)

        plt.subplot(num_metrics,1,i+1)
        m = plt.plot(y,values,color)
        plt.legend(m,[name],loc=1)

    plt.show()

    if save_metric is not None:
        plt.imsave(save_metric)




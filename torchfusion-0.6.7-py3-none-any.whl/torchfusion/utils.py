import matplotlib.pyplot as plt
from PIL import Image
import torchvision.transforms as transforms
from torch.utils.data import Dataset
import torch
import os
from collections import namedtuple
def adjust_learning_rate(lr,optimizer):
    for param_group in optimizer.param_groups:
        param_group["lr"] = lr


PlotInput = namedtuple("PlotInput",["value","name","color"])

def visualize(y, x,save_path=None):

    num_metrics = len(x)
    plt.figure(1)
    for i,x_ in enumerate(x):
        plt.subplot(num_metrics,1,i+1)
        m = plt.plot(y,x_.value,x_.color)
        plt.legend(m,[x_.name],loc=1)
    if save_path is not None:
        plt.savefig(save_path)
    plt.show()





def load_images(image_paths,size,normalization=((0.5,0.5,0.5),(0.5,0.5,0.5))):

    images = []
    for image_path in image_paths:
        img = Image.open(image_path)

        transformations = transforms.Compose([
            transforms.Resize(size),
            transforms.ToTensor(),
            transforms.Normalize(normalization[0],normalization[1])
        ])

        img = transformations(img)
        images.append(img)

    return images










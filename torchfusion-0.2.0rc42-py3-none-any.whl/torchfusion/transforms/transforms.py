import torch


class ToTensor(object):
    def __call__(self, input):
        return torch.tensor(input)

class Normalize(object):
    def __init__(self,mean,std):
        self.mean = mean
        self.std = std
    def __call__(self, input):
        return input.sub_(self.mean).div_(self.std)

class Compose(object):
    def __init__(self,transforms):
        self.transforms = transforms

    def __call__(self, input):

        for trans in self.transforms:
            input = trans(input)
        return input


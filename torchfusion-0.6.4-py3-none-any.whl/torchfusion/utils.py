import matplotlib.pyplot as plt
from PIL import Image
import torchvision.transforms as transforms
from torch.utils.data import Dataset
import torch
import os

def adjust_learning_rate(lr,optimizer):
    for param_group in optimizer.param_groups:
        param_group["lr"] = lr


def visualize_metrics(y, x,save_path=None):

    num_metrics = len(x)
    plt.figure(1)
    for i,(values,name,color) in enumerate(x):
        print(values,name,color)

        plt.subplot(num_metrics,1,i+1)
        m = plt.plot(y,values,color)
        plt.legend(m,[name],loc=1)

    plt.show()

    if save_path is not None:
        plt.imsave(save_path)



def load_images(image_paths,size,normalization=((0.5,0.5,0.5),(0.5,0.5,0.5))):

    images = []
    for image_path in image_paths:
        img = Image.open(image_path)

        transformations = transforms.Compose([
            transforms.Resize(size),
            transforms.ToTensor(),
            transforms.Normalize(normalization[0],normalization[1])
        ])

        img = transformations(img)
        images.append(img)

    return images


class ImagesFromPaths(Dataset):
    def __init__(self,image_paths,transformations,recursive=True,allowed_exts=["jpg","png","jpeg","tif"]):
        super(ImagesFromPaths).__init__()
        assert isinstance(image_paths,list)

        self.transformations = transformations

        self.image_array = []

        for path in image_paths:


            if os.path.exists(path) == False:
                path = os.path.join(os.getcwd(),path)

            if os.path.isdir(path):

                if recursive:
                    for root, dirs, files in os.walk(path):
                        for fname in files:
                            fpath = os.path.join(root,fname)

                            if self.__get_extension(fpath) in allowed_exts:
                                self.image_array.append(fpath)
                else:
                    for fpath in os.listdir(path):
                        fpath = os.path.join(path,fpath)
                        if self.__get_extension(fpath) in allowed_exts:
                            self.image_array.append(fpath)

            elif os.path.isfile(path):
                if self.__get_extension(path) in allowed_exts:
                    self.image_array.append(path)

    def __get_extension(self,fpath):
        split = fpath.split(".")
        return split[len(split) - 1]

    def __getitem__(self, index):

        img = Image.open(self.image_array[index])
        img = self.transformations(img)

        return img

    def __len__(self):
        return len(self.image_array)









from collections import namedtuple
import torch.nn as nn
from torchfusion.utils import *
from torchfusion.learners import AbstractBaseLearner
from torchfusion.gan.utils import ImagePool

import torch
from torch.autograd import Variable, grad
import torch.cuda as cuda
from torchvision import utils as vutils
import os
from time import time
import numpy as np
import matplotlib.pyplot as plt
from torchfusion.utils import PlotInput, visualize
from torch.utils.data import DataLoader
from tensorboardX import SummaryWriter
import torch.distributions as distribution
import torch.nn.functional as F
from torch.optim.lr_scheduler import ReduceLROnPlateau
import torch.onnx as onnx

r"""This is the base Learner for training, evaluating and performing inference with Generative Adversarial Networks
Goodfellow et al. 2014 (https://arxiv.org/1406.2661)
All custom GAN learners that use a single Generator and a single Discriminator should subclass this 

    Args:
        gen_model (Module):  the generator module.
        disc_model (Module):  the discriminator module.
        use_cuda_if_available (boolean): If set to true, training would be done on a gpu if any is available"""


class BaseGANModel():
    def __init__(self, gen_model, disc_model, use_cuda_if_available=True):
        self.model_dir = os.getcwd()
        self.gen_model = gen_model
        self.disc_model = disc_model
        self.cuda = False
        if use_cuda_if_available and cuda.is_available():
            self.cuda = True

        self.gen_loss_history = []
        self.disc_loss_history = []

        self.__input_hooks = []

        self.visdom_log = None
        self.tensorboard_log = None

    r"""Initialize generator model weights using pre-trained weights from the filepath

        Args:
            path (str): path to a compatible pre-defined model

        """

    def load_generator(self, path):
        checkpoint = torch.load(path)
        self.gen_model.load_state_dict(checkpoint)

    r"""Initialize discriminator model weights using pre-trained weights from the filepath

        Args:
            path (str): path to a compatible pre-defined model

        """

    def load_discriminator(self, path):
        checkpoint = torch.load(path)
        self.disc_model.load_state_dict(checkpoint)

    r"""Saves the generator model to the path specified
            Args:
                path (str): path to save model
                save_architecture (boolean): if True, both weights and architecture will be saved, default is False

            """

    def save_generator(self, path, save_architecture=False):
        if save_architecture:
            torch.save(self.gen_model, path)
        else:
            torch.save(self.gen_model.state_dict(), path)

    r"""Saves the discriminator model to the path specified
            Args:
                path (str): path to save model
                save_architecture (boolean): if True, both weights and architecture will be saved, default is False

            """

    def save_discriminator(self, path, save_architecture=False):
        if save_architecture:
            torch.save(self.disc_model, path)
        else:
            torch.save(self.disc_model.state_dict(), path)

    def gen_to_onnx(self, inputs, path, **kwargs):

        if isinstance(inputs, tuple):
            in_tensors = []
            for input in inputs:
                in_tensors.append(Variable(input.cuda() if self.cuda else input))
        else:
            in_tensors = Variable(inputs.cuda() if self.cuda else inputs)

        return onnx._export(self.gen_model, in_tensors, f=path, **kwargs)

    def disc_to_onnx(self, inputs, path, **kwargs):

        if isinstance(inputs, tuple):
            in_tensors = []
            for input in inputs:
                in_tensors.append(Variable(input.cuda() if self.cuda else input))
        else:
            in_tensors = Variable(inputs.cuda() if self.cuda else inputs)

        return onnx._export(self.disc_model, in_tensors, f=path, **kwargs)

    r"""Complete Training loop

            Args:
                train_loader (DataLoader): an instance of DataLoader containing the training set
                gen_optimizer (Optimizer): an optimizer for updating parameters of the generator
                disc_optimizer (Optimizer): an optimizer for updating parameters of the discriminator
                num_epochs (int): The maximum number of training epochs
                disc_steps (int): The number of times to train the discriminator before training generator
                save_models (str): If all, the model is saved at the end of each epoch while the best models based 
                gen_lr_scheduler (_LRScheduler): Learning rate scheduler for the generator
                disc_lr_scheduler (_LRScheduler): Learning rate sheduler for the discriminator
                    on the test set are also saved in best_models folder
                    If 'best', only the best models are saved,  test_loader and test_metrics must be provided
                model_dir (str) = a path in which to save the models
                save_interval (int): Saves sample generated outputs at the the number of iterations specified
                notebook_mode (boolean): Optimizes the progress bar for either jupyter notebooks or consoles
                batch_log (boolean): Enables printing of logs at every batch iteration
                save_logs (str): Specifies a filepath in which to permanently save logs at every epoch
                display_metrics (boolean): Enables display of metrics and loss visualizations at the end of each epoch.
                save_metrics (boolean): Enables saving of metrics and loss visualizations at the end of each epoch.
                visdom_log (VisdomLogger): Logs outputs and metrics to the visdom server
                tensorboard_log (str): Logs outputs and metrics to the filepath for visualization in tensorboard
                save_architecture (boolean): Saves the architecture as well as weights during model saving

                """

    def train(self, target,source,gen_optimizer,disc_optimizer,num_epochs=10, disc_steps=1, gen_lr_schedule=None,disc_lr_schedule=None, model_dir=os.getcwd(), save_interval=100,notebook_mode=False,batch_log=True,save_logs=None,display_metrics=True,save_metrics=True, visdom_log=None, tensorboard_log=None,
              save_architecture=False):
        assert (disc_steps < len(target.dataset))

        self.gen_optimizer = gen_optimizer
        self.disc_optimizer = disc_optimizer
        self.tensorboard_log = tensorboard_log
        self.visdom_log = visdom_log

        if not os.path.exists(model_dir):
            os.mkdir(model_dir)

        self.model_dir = model_dir
        models_gen = os.path.join(model_dir, "gen_models")
        models_disc = os.path.join(model_dir, "disc_models")

        if not os.path.exists(models_gen):
            os.mkdir(models_gen)

        if not os.path.exists(models_disc):
            os.mkdir(models_disc)

        iterations = 0

        from tqdm import tqdm_notebook
        from tqdm import tqdm

        train_start_time = time()

        for e in range(num_epochs):

            self.gen_model.train()
            self.disc_model.train()

            self.on_epoch_start(e+1)

            gen_running_loss = torch.Tensor([0.0])
            disc_running_loss = torch.Tensor([0.0])
            gen_loss = 0
            disc_loss = 0

            gen_data_len = 0
            disc_data_len = 0

            if notebook_mode and batch_log:
                progress_ = tqdm_notebook(enumerate(zip(target,source)))
            elif batch_log:
                progress_ = tqdm(enumerate(zip(target,source)))
            else:
                progress_ = enumerate(zip(target,source))

            init_time = time()

            for i,(t,s) in progress_:

                self.on_batch_start(e+1,i+1)

                if isinstance(t, list) or isinstance(t, tuple):
                    inputs = t[0]
                else:
                    inputs = t
                batch_size = inputs.size(0)
                disc_data_len += batch_size
                
                if len(self.__input_hooks) > 0:

                    for hook in self.__input_hooks:
                        inputs = hook(inputs)

                if isinstance(t, list):
                    t[0] = inputs
                elif isinstance(t, tuple):
                    t = (inputs,t[1])
                else:
                    t = inputs


                self.__disc_train_func(t,s,disc_optimizer,disc_running_loss,e+1,i+1)

                disc_loss = disc_running_loss.data.item() / disc_data_len

                if (i + 1) % disc_steps == 0:
                    self.__gen_train_func(t)
                    gen_data_len += batch_size

                    gen_loss = gen_running_loss.data.item() / gen_data_len

                if batch_log:
                    progress_dict = {"Gen Loss": gen_loss, "Disc Loss": disc_loss}
                    progress_.set_postfix(progress_dict)

                iterations += 1

                if iterations % save_interval == 0:
                    self.__save(iterations)
                    self.__show(iterations)

                self.on_batch_end(e+1,i+1,gen_loss,disc_loss)

            if self.cuda:
                cuda.synchronize()
            duration = time() - init_time


            self.disc_loss_history.append(disc_loss)
            self.gen_loss_history.append(gen_loss)

            model_file = os.path.join(models_gen, "gen_model_{}.pth".format(e + 1))
            self.save_generator(model_file, save_architecture)

            model_file = os.path.join(models_disc, "disc_model_{}.pth".format(e + 1))
            self.save_discriminator(model_file, save_architecture)

            print("Epoch: {}, Duration: {} , Gen Loss: {} Disc Loss: {}".format(e + 1, duration, gen_loss, disc_loss))

            if save_logs is not None:
                logfile = open(save_logs, "a")
                logfile.write(
                    "Epoch: {}, Duration: {} , Gen Loss: {} Disc Loss: {}".format(e + 1, duration, gen_loss, disc_loss))
                logfile.close()

            epoch_arr = [x for x in range(e + 1)]

            if display_metrics or save_metrics:

                save_path = None

                if save_metrics:
                    save_path = os.path.join(model_dir, "epoch_{}_loss.png".format(e + 1))

                visualize(epoch_arr, [PlotInput(value=self.gen_loss_history, name="Generator Loss", color="red"),
                                      PlotInput(value=self.disc_loss_history, name="Discriminator Loss", color="red")],
                          display=display_metrics,
                          save_path=save_path)

            self.on_epoch_end(e+1,gen_loss,disc_loss,duration)

            epoch_arr_tensor = torch.LongTensor(epoch_arr)

            if visdom_log is not None:
                visdom_log.plot_line(torch.FloatTensor(self.gen_loss_history), epoch_arr_tensor, win="gen_loss",
                                     title="Generator Loss")

                visdom_log.plot_line(torch.FloatTensor(self.disc_loss_history), epoch_arr_tensor, win="disc_loss",
                                     title="Discriminator Loss")

            if tensorboard_log is not None:
                writer = SummaryWriter(os.path.join(model_dir, tensorboard_log))
                for epoch in epoch_arr:
                    writer.add_scalar("logs/gen_loss", self.gen_loss_history[epoch], global_step=epoch)
                    writer.add_scalar("logs/disc_loss", self.disc_loss_history[epoch], global_step=epoch)

            self.on_epoch_end(e+1,gen_loss,disc_loss,duration)

        train_end_time = time() - train_start_time
        self.on_training_completed(train_end_time)

    """ Abstract function containing the training logic for the generator, 
     all custom trainers must override this.

        Arguments:
            target: a single batch of data from the target set
            source: a single batch of data from the source set
            gen_optimizer: the optimizer for the generator
            running_loss: the current generator running loss
            epoch: current epoch
            batch_num: the current batch index
            """

    def __gen_train_func(self, data):
        raise NotImplementedError()

    """ Abstract function containing the training logic for the discriminator, 
         all custom trainers must override this.

            Arguments:
                target: a single batch of data from the target set
                source: a single batch of data from the source set
                disc_optimizer: the optimizer for the discriminator
                running_loss: the current generator running loss
                epoch: current epoch
                batch_num: the current batch index
                """

    def __disc_train_func(self, target,source,disc_optimizer,running_loss,epoch,batch_num):
        raise NotImplementedError()

    """ Abstract function containing logic to save the outputs of the generator, 
         all custom trainers must override this.

            Arguments:
                source: a single batch of data from the source set
                iterations: total number of batch iterations since the start of training
                """

    """ Abstract function containing logic to save the outputs of the generator, 
             all custom trainers must override this.

                Arguments:
                    source: a single batch of data from the source set
                    iterations: total number of batch iterations since the start of training
                    """

    def show(self, source, iterations):
        raise NotImplementedError()

    def save(self, source, iterations):
        raise NotImplementedError()

    """ Abstract function containing logic to display the outputs of the generator, 
             all custom trainers must override this.

                Arguments:
                    source: a single batch of data from the source set
                    iterations: total number of batch iterations since the start of training
                    """

    """ Returns predictions for a given input tensor or a an instance of a DataLoader
            Arguments:
                inputs: input Tensor or DataLoader
    """

    def predict(self, inputs):
        self.gen_model.eval()

        if isinstance(inputs, DataLoader):
            predictions = []
            for i, data in enumerate(inputs):
                pred = self.__predict_func(data)
                predictions.append(pred)

            output_array = []

            for batch in predictions:
                for pred in batch:
                    output_array.append(pred)
            return output_array
        else:
            pred = self.__predict_func(inputs)

            return pred

    """ Abstract function containing custom logic for performing inference, must return the output,
            all custom trainers should implement this.
            input: An input tensor or a batch of input tensors
            """

    def __predict_func(self, input):
        raise NotImplementedError()

    """ Callback that is invoked at the start of each epoch,
                epoch: the current epoch
                """

    def on_epoch_start(self, epoch):
        pass

    """ Callback that is invoked at the end of each epoch,
               epoch: the current epoch
               gen_loss: the running loss for the generator
               disc_loss: the running loss for the discriminator
               duration: Total duration of the current epoch
               """

    def on_epoch_end(self, epoch, gen_loss, disc_loss, duration):
        pass

    """ Callback that is invoked at the start of each batch,
                epoch: the current epoch
                batch_num: The current batch index
        """

    def on_batch_start(self, epoch, batch_num):
        pass

    """ Callback that is invoked at the end of each batch,
                  epoch: the current epoch
                  batch_num: the current batch index
                  gen_loss: the running loss for the generator
                  disc_loss: the running loss for the discriminator
                   """

    def on_batch_end(self, epoch, batch_num, gen_loss, disc_loss):
        pass

    """ Callback that is invoked at the end of training,
                  train_duration: the total duration of training
                   """

    def on_training_completed(self, train_duration):
        pass

    """ Returns a detailed summary of the generator, including input and output sizes, computational cost in flops,
        number of parameters and number of layers of each type
            input_size: The size of the input tensor
            """


""" StandardGANModel model suitable for unconditional GANS with an explicit loss function
    Arguments:
    gen_model:  the generator module.
    disc_model:  the discriminator module.
    gen_loss_fn: the loss function to be used for the generator
    disc_loss_fn: the loss function to be used for the discriminator
    smooth_labels: if True, real labels range between 0.7 - 1.2 and fake labels range between 0.0 - 0.3
    use_cuda_if_available: If set to true, training would be done on a gpu if any is available

"""


class StandardGANModel(BaseGANModel):
    def __init__(self, gen_model, disc_model, gen_loss_fn,disc_loss_fn,smooth_labels=False,use_cuda_if_available=True):
        super(StandardGANModel, self).__init__(gen_model, disc_model, use_cuda_if_available)
        self.gen_loss_fn = gen_loss_fn
        self.disc_loss_fn = disc_loss_fn

        self.smooth_labels = smooth_labels
        

    def __disc_train_func(self, target, source, optimizer,running_loss, epoch, batch_num):

        for params in self.disc_model.parameters():
            params.requires_grad = True

        for params in self.gen_model.parameters():
            params.requires_grad = False

        optimizer.zero_grad()

        optimizer.zero_grad()

        if isinstance(target, list) or isinstance(target, tuple):
            x = target[0]
        else:
            x = target

        batch_size = x.size(0)

        if self.smooth_labels:
            real_labels = torch.randn(batch_size).uniform_(0.7, 1.2)
            fake_labels = torch.randn(batch_size).uniform_(0.0, 0.3)
        else:
            real_labels = torch.ones(batch_size)
            fake_labels = torch.zeros(batch_size)

        if self.cuda:
            x = x.cuda()
            source = source.cuda()
            real_labels = real_labels.cuda()
            fake_labels = fake_labels.cuda()

        x = Variable(x)
        source = Variable(source)
        real_labels = Variable(real_labels)
        fake_labels = Variable(fake_labels)

        outputs = self.disc_model(x)

        real_loss = self.disc_loss_fn(outputs, real_labels)
        real_loss.backward()

        generated = self.gen_model(source)
        gen_outputs = self.disc_model(generated.detach())

        fake_loss = self.disc_loss_fn(gen_outputs, fake_labels)
        fake_loss.backward()

        optimizer.step()

        d_loss = real_loss + fake_loss

        running_loss.add_(d_loss.cpu() * batch_size)

    def __gen_train_func(self, target, source, optimizer, running_loss, epoch, batch_num):

        for params in self.gen_model.parameters():
            params.requires_grad = True

        for params in self.disc_model.parameters():
            params.requires_grad = False

        if isinstance(target, list) or isinstance(target, tuple):
            x = target[0]
        else:
            x = target
        batch_size = x.size(0)
        labels = torch.ones(batch_size)
        if self.smooth_labels:
            labels = torch.randn(batch_size).uniform_(0.7,1.2)

        if self.cuda:
            source = source.cuda()
            labels = labels.cuda()

        source = Variable(source)
        labels = Variable(labels)

        fake_images = self.gen_model(source)
        outputs = self.disc_model(fake_images)

        loss = self.gen_loss_fn(outputs, labels)
        loss.backward()

        optimizer.step()

        running_loss.add_(loss.cpu() * batch_size)


    def save(self,source, iteration):

        save_dir = os.path.join(self.model_dir, "gen_images")

        if os.path.exists(save_dir) == False:
            os.mkdir(save_dir)
        if self.tensorboard_log is not None:
            writer = SummaryWriter(self.tensorboard_log)


        if self.cuda:
            source = source.cuda()

        source = Variable(source)
        outputs = self.gen_model(source)
        images_file = os.path.join(save_dir, "image_{}.png".format(iteration))

        vutils.save_image(outputs.cpu().data, images_file, normalize=True)

        if self.tensorboard_log is not None:
            writer.add_image("logs/gen_images", outputs.cpu().data, global_step=iteration)

        if self.visdom_log is not None:
            self.visdom_log.log_images(outputs.cpu().data, win="gen_images", title="Generated Images")

        if self.tensorboard_log:
            writer.close()

    def show(self, source, iteration):

        
        if self.cuda:
            source = source.cuda()

        source = Variable(source)
        outputs = self.gen_model(source)

        images = vutils.make_grid(outputs.cpu().data, normalize=True)

        images = np.transpose(images.numpy(), (1, 2, 0))
        plt.imshow(images)
        plt.axis("off")
        plt.grid(False)
        plt.show()

    def __predict_func(self, source):

        source = Variable(source)
        if self.cuda:
            source = source.cuda()

        source = Variable(source)
        outputs = self.gen_model(source)

        return outputs

    def gen_summary(self, input_size, input_type=torch.FloatTensor, item_length=26, tensorboard_log=None):
        input = torch.randn(input_size).type(input_type).unsqueeze(0)

        if self.cuda:
            input.cuda()

        return get_model_summary(self.model, Variable(input), item_length=item_length, tensorboard_log=tensorboard_log)

    def gen_to_onnx(self, input_size,
                    path, input_type=torch.FloatTensor, **kwargs):
        input = torch.randn(input_size).type(input_type).unsqueeze(0)

        if self.cuda:
            input.cuda()

        return super(StandardGanLearner, self).gen_to_onnx(Variable(input), path=path, **kwargs)

    def add_input_hook(self, function):
        self.__input_hooks.append(function)


class WGanLearner(BaseGanLearner):
    def __init__(self, gen_model, disc_model, latent_size=None, lambda_=0.25, dist=distribution.Normal(0, 1),
                 num_classes=None, num_samples=5, use_cuda_if_available=True):
        super(WGanLearner, self).__init__(gen_model, disc_model, use_cuda_if_available)
        self.lambda_ = lambda_
        self.latent_size = latent_size
        self.dist = dist
        self.fixed_source = None

        self.conditional = (num_classes is not None)
        self.classes = num_classes
        self.num_samples = num_samples

    def __disc_train_func(self, data):

        for params in self.disc_model.parameters():
            params.requires_grad = True

        for params in self.gen_model.parameters():
            params.requires_grad = False

        self.disc_optimizer.zero_grad()

        if isinstance(data, list) or isinstance(data, tuple):
            x = data[0]
            if self.conditional:
                class_labels = data[1]
        else:
            if self.conditional:
                raise ValueError("Conditional mode is invalid for inputs with no labels")
            x = data

        batch_size = x.size(0)
        if isinstance(self.latent_size, int):
            source_size = list([self.latent_size])
        else:
            source_size = list(self.latent_size)
        non_batched_size = [self.num_samples] + source_size
        source_size = [batch_size] + source_size

        source = self.dist.sample(tuple(source_size))

        if self.fixed_source is None:

            if self.conditional:
                self.fixed_source = self.dist.sample(tuple(non_batched_size))

            else:
                self.fixed_source = self.dist.sample(tuple(source_size))

            if self.cuda:
                self.fixed_source = self.fixed_source.cuda()

            self.fixed_source = Variable(self.fixed_source)

        if self.cuda:
            x = x.cuda()
            source = source.cuda()
            if self.conditional:
                class_labels = class_labels.cuda()

        x = Variable(x)
        source = Variable(source)
        if self.conditional:
            class_labels = Variable(class_labels)

        if self.conditional:
            outputs = self.disc_model(x, class_labels.unsqueeze(1))
        else:
            outputs = self.disc_model(x)

        real_loss = -torch.mean(outputs)
        real_loss.backward()

        if self.conditional:
            random_labels = torch.from_numpy(np.random.randint(0, self.classes, size=(batch_size, 1))).long()
            if self.cuda:
                random_labels = random_labels.cuda()

            random_labels = Variable(random_labels)

            generated = self.gen_model(source, random_labels)
            gen_outputs = self.disc_model(generated.detach(), random_labels)

        else:
            generated = self.gen_model(source)
            gen_outputs = self.disc_model(generated.detach())

        fake_loss = torch.mean(gen_outputs)
        fake_loss.backward()

        eps = torch.randn(x.size()).uniform_(0, 1)

        if self.cuda:
            eps = eps.cuda()

        x__ = Variable(eps * x.data + (1.0 - eps) * generated.data, requires_grad=True)

        pred__ = self.disc_model(x__)

        grad_outputs = torch.ones(pred__.size())

        if self.cuda:
            grad_outputs = grad_outputs.cuda()

        gradients = grad(outputs=pred__, inputs=x__, grad_outputs=grad_outputs, create_graph=True, retain_graph=True,
                         only_inputs=True)[0]

        gradient_penalty = self.lambda_ * ((gradients.view(gradients.size(0), -1).norm(2, 1) - 1) ** 2).mean()

        gradient_penalty.backward()

        self.disc_optimizer.step()

        d_loss = real_loss + fake_loss + gradient_penalty

        self.disc_running_loss.add_(d_loss.cpu() * batch_size)

    def __gen_train_func(self, data):

        for params in self.gen_model.parameters():
            params.requires_grad = True

        for params in self.disc_model.parameters():
            params.requires_grad = False

        self.gen_optimizer.zero_grad()

        if isinstance(data, list) or isinstance(data, tuple):
            x = data[0]
        else:
            x = data
        batch_size = x.size(0)

        if isinstance(self.latent_size, int):
            source_size = list([self.latent_size])
        else:
            source_size = list(self.latent_size)

        source_size = [batch_size] + source_size

        source = self.dist.sample(tuple(source_size))
        if self.conditional:
            random_labels = torch.from_numpy(np.random.randint(0, self.classes, size=(batch_size, 1))).long()
            if self.cuda:
                random_labels = random_labels.cuda()

            random_labels = Variable(random_labels)

        if self.cuda:
            source = source.cuda()

        source = Variable(source)

        if self.conditional:
            fake_images = self.gen_model(source, random_labels)
            outputs = self.disc_model(fake_images, random_labels)
        else:
            fake_images = self.gen_model(source)
            outputs = self.disc_model(fake_images)

        loss = -torch.mean(outputs)
        loss.backward()

        self.gen_optimizer.step()

        self.gen_running_loss.add_(loss.cpu() * batch_size)

    def __save(self, iteration):

        save_dir = os.path.join(self.model_dir, "gen_images")

        if os.path.exists(save_dir) == False:
            os.mkdir(save_dir)
        if self.tensorboard_log is not None:
            writer = SummaryWriter(self.tensorboard_log)

        if self.conditional:

            for i in range(self.classes):
                class_labels = torch.randn((self.num_samples, 1)).type(torch.LongTensor).fill_(i)

                if self.cuda:
                    class_labels.cuda()

                class_labels = Variable(class_labels)
                outputs = self.gen_model(self.fixed_source, class_labels)

                images_file = os.path.join(save_dir, "class_{}_iteration{}.png".format(i, iteration))

                images = vutils.make_grid(outputs.cpu().data, normalize=True)
                vutils.save_image(outputs.cpu().data, images_file, normalize=True)

                if self.tensorboard_log is not None:
                    writer.add_image("logs/gen_images/class_{}".format(i), images, global_step=iteration)

                if self.visdom_log is not None:
                    self.visdom_log.log_images(images, win="class_{}".format(i), title="Class {}".format(i))

        else:
            outputs = self.gen_model(self.fixed_source)
            images_file = os.path.join(save_dir, "image_{}.png".format(iteration))

            vutils.save_image(outputs.cpu().data, images_file, normalize=True)

            if self.tensorboard_log is not None:
                writer.add_image("logs/gen_images", outputs.cpu().data, global_step=iteration)

            if self.visdom_log is not None:
                self.visdom_log.log_images(outputs.cpu().data, win="gen_images", title="Generated Images")
        if self.tensorboard_log:
            writer.close()

    def __show(self, iteration):

        if self.conditional:
            for i in range(self.classes):
                class_labels = torch.randn((self.num_samples, 1)).type(torch.LongTensor).fill_(i)

                if self.cuda:
                    class_labels.cuda()

                class_labels = Variable(class_labels)
                outputs = self.gen_model(self.fixed_source, class_labels)

                images = vutils.make_grid(outputs.cpu().data, normalize=True)
                images = np.transpose(images.numpy(), (1, 2, 0))
                plt.subplot(self.classes, 1, i + 1)
                plt.axis("off")
                # plt.title("class {}".format(i))
                plt.imshow(images)

            plt.show()

        else:
            outputs = self.gen_model(self.fixed_source)

            images = vutils.make_grid(outputs.cpu().data, normalize=True)

            images = np.transpose(images.numpy(), (1, 2, 0))
            plt.imshow(images)
            plt.axis("off")
            plt.grid(False)
            plt.show()

    def __predict_func(self, data):

        if isinstance(data, list) or isinstance(data, tuple):
            source = data[0]
            if self.conditional:
                labels = data[1]
        else:
            source = data

        if self.cuda:
            source = source.cuda()
            if self.conditional:
                labels = labels.cuda()

        source = Variable(source)
        if self.conditional:
            labels = Variable(labels)
        if self.conditional:
            outputs = self.gen_model(source, labels)
        else:
            outputs = self.gen_model(source)

        return outputs


class HingeGanLearner(BaseGanLearner):
    def __init__(self, gen_model, disc_model, latent_size=None, dist=distribution.Normal(0, 1),
                 num_classes=None, num_samples=5, use_cuda_if_available=True):
        super(HingeGanLearner, self).__init__(gen_model, disc_model, use_cuda_if_available)
        self.latent_size = latent_size
        self.dist = dist
        self.fixed_source = None

        self.conditional = (num_classes is not None)
        self.classes = num_classes
        self.num_samples = num_samples

    def __disc_train_func(self, data):

        for params in self.disc_model.parameters():
            params.requires_grad = True

        for params in self.gen_model.parameters():
            params.requires_grad = False

        self.disc_optimizer.zero_grad()

        if isinstance(data, list) or isinstance(data, tuple):
            x = data[0]
            if self.conditional:
                class_labels = data[1]
        else:
            if self.conditional:
                raise ValueError("Conditional mode is invalid for inputs with no labels")
            x = data

        batch_size = x.size(0)
        if isinstance(self.latent_size, int):
            source_size = list([self.latent_size])
        else:
            source_size = list(self.latent_size)
        non_batched_size = [self.num_samples] + source_size
        source_size = [batch_size] + source_size

        source = self.dist.sample(tuple(source_size))

        if self.fixed_source is None:

            if self.conditional:
                self.fixed_source = self.dist.sample(tuple(non_batched_size))

            else:
                self.fixed_source = self.dist.sample(tuple(source_size))

            if self.cuda:
                self.fixed_source = self.fixed_source.cuda()

            self.fixed_source = Variable(self.fixed_source)

        if self.cuda:
            x = x.cuda()
            source = source.cuda()
            if self.conditional:
                class_labels = class_labels.cuda()

        x = Variable(x)
        source = Variable(source)
        if self.conditional:
            class_labels = Variable(class_labels)

        if self.conditional:
            outputs = self.disc_model(x, class_labels.unsqueeze(1))
        else:
            outputs = self.disc_model(x)

        real_loss = -torch.mean(F.relu(-1 + outputs))
        real_loss.backward()

        if self.conditional:
            random_labels = torch.from_numpy(np.random.randint(0, self.classes, size=(batch_size, 1))).long()
            if self.cuda:
                random_labels = random_labels.cuda()

            random_labels = Variable(random_labels)

            generated = self.gen_model(source, random_labels)
            gen_outputs = self.disc_model(generated.detach(), random_labels)

        else:
            generated = self.gen_model(source)
            gen_outputs = self.disc_model(generated.detach())

        fake_loss = torch.mean(F.relu(-1 - gen_outputs))
        fake_loss.backward()

        self.disc_optimizer.step()

        d_loss = real_loss + fake_loss

        self.disc_running_loss.add_(d_loss.cpu() * batch_size)

    def __gen_train_func(self, data):

        for params in self.gen_model.parameters():
            params.requires_grad = True

        for params in self.disc_model.parameters():
            params.requires_grad = False

        self.gen_optimizer.zero_grad()

        if isinstance(data, list) or isinstance(data, tuple):
            x = data[0]
        else:
            x = data
        batch_size = x.size(0)

        if isinstance(self.latent_size, int):
            source_size = list([self.latent_size])
        else:
            source_size = list(self.latent_size)

        source_size = [batch_size] + source_size

        source = self.dist.sample(tuple(source_size))
        if self.conditional:
            random_labels = torch.from_numpy(np.random.randint(0, self.classes, size=(batch_size, 1))).long()
            if self.cuda:
                random_labels = random_labels.cuda()

            random_labels = Variable(random_labels)

        if self.cuda:
            source = source.cuda()

        source = Variable(source)

        if self.conditional:
            fake_images = self.gen_model(source, random_labels)
            outputs = self.disc_model(fake_images, random_labels)
        else:
            fake_images = self.gen_model(source)
            outputs = self.disc_model(fake_images)

        loss = -torch.mean(outputs)
        loss.backward()

        self.gen_optimizer.step()

        self.gen_running_loss.add_(loss.cpu() * batch_size)

    def __save(self, iteration):

        save_dir = os.path.join(self.model_dir, "gen_images")

        if os.path.exists(save_dir) == False:
            os.mkdir(save_dir)
        if self.tensorboard_log is not None:
            writer = SummaryWriter(self.tensorboard_log)

        if self.conditional:

            for i in range(self.classes):
                class_labels = torch.randn((self.num_samples, 1)).type(torch.LongTensor).fill_(i)

                if self.cuda:
                    class_labels.cuda()

                class_labels = Variable(class_labels)
                outputs = self.gen_model(self.fixed_source, class_labels)

                images_file = os.path.join(save_dir, "class_{}_iteration{}.png".format(i, iteration))

                images = vutils.make_grid(outputs.cpu().data, normalize=True)
                vutils.save_image(outputs.cpu().data, images_file, normalize=True)

                if self.tensorboard_log is not None:
                    writer.add_image("logs/gen_images/class_{}".format(i), images, global_step=iteration)

                if self.visdom_log is not None:
                    self.visdom_log.log_images(images, win="class_{}".format(i), title="Class {}".format(i))

        else:
            outputs = self.gen_model(self.fixed_source)
            images_file = os.path.join(save_dir, "image_{}.png".format(iteration))

            vutils.save_image(outputs.cpu().data, images_file, normalize=True)

            if self.tensorboard_log is not None:
                writer.add_image("logs/gen_images", outputs.cpu().data, global_step=iteration)

            if self.visdom_log is not None:
                self.visdom_log.log_images(outputs.cpu().data, win="gen_images", title="Generated Images")
        if self.tensorboard_log:
            writer.close()

    def __show(self, iteration):

        if self.conditional:
            for i in range(self.classes):
                class_labels = torch.randn((self.num_samples, 1)).type(torch.LongTensor).fill_(i)

                if self.cuda:
                    class_labels.cuda()

                class_labels = Variable(class_labels)
                outputs = self.gen_model(self.fixed_source, class_labels)

                images = vutils.make_grid(outputs.cpu().data, normalize=True)
                images = np.transpose(images.numpy(), (1, 2, 0))
                plt.subplot(self.classes, 1, i + 1)
                plt.axis("off")
                # plt.title("class {}".format(i))
                plt.imshow(images)

            plt.show()

        else:
            outputs = self.gen_model(self.fixed_source)

            images = vutils.make_grid(outputs.cpu().data, normalize=True)

            images = np.transpose(images.numpy(), (1, 2, 0))
            plt.imshow(images)
            plt.axis("off")
            plt.grid(False)
            plt.show()

    def __predict_func(self, data):

        if isinstance(data, list) or isinstance(data, tuple):
            source = data[0]
            if self.conditional:
                labels = data[1]
        else:
            source = data

        if self.cuda:
            source = source.cuda()
            if self.conditional:
                labels = labels.cuda()

        source = Variable(source)
        if self.conditional:
            labels = Variable(labels)
        if self.conditional:
            outputs = self.gen_model(source, labels)
        else:
            outputs = self.gen_model(source)

        return outputs

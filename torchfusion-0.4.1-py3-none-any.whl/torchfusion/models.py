import torch
from torch.autograd import Variable
import torch.cuda as cuda
from torch.utils.data import DataLoader
from .utils import *
import os
from time import time
import warnings
from collections import namedtuple
import torch.nn as nn

"""This is the base Model for training, evaluating and performing inference
All custom trainers should subclass this 

Arguments:
    model:  the module to be used for training, evaluation and inference.
    use_cuda_if_available: If set to true, training would be done on a gpu if any is available"""
class BaseModel():
    def __init__(self, model,use_cuda_if_available=True):
        self.model = model
        self.cuda = False
        if use_cuda_if_available and cuda.is_available():
            self.cuda = True
        self.loss_history = []

        self.__best_metric = 0.0

    """Loads a pretrained model into the model 

    Arguments:
        path: a filepath or read-stream of an existing pre-trained model """

    def load_model(self, path):
        checkpoint = torch.load(path)
        self.model.load_state_dict(checkpoint)

    """ Loads a pretrained model into the model 

        Arguments:
            path: a filepath or write-stream to save the trained model"""

    def save_model(self, path):
        torch.save(self.model.state_dict(), path)

    """traner function for the model 

            Arguments:
                train_loader: a filepath or write-stream to save the trained model

            """
    def train(self, train_loader, loss_fn, optimizer,train_metrics,test_loader=None,test_metrics=None, num_epochs=10, lr_schedule=None,
              save_models="all", model_dir=os.getcwd()):

        if save_models not in ["all", "best"]:
            raise ValueError("save models must be 'all' or 'best' , {} is invalid".format(save_models))
        if save_models == "best" and test_loader is None:
            raise ValueError("save models can only be best when testloader is provided")

        if test_loader is not None:
            if test_metrics is None:
                raise ValueError("You must provide a metric for your test data")
            elif len(test_loader) == 0:
                raise ValueError("test metrics cannot be an empty list")

        models_all = os.path.join(model_dir, "all_models")
        models_best = os.path.join(model_dir, "best_models")

        if not os.path.exists(models_all):
            os.mkdir(models_all)


        if not os.path.exists(models_best) and test_loader is not None:
            os.mkdir(models_best)


        for e in range(num_epochs):

            for metric in train_metrics:
                metric.reset()

            self.model.train()
            self.on_epoch_start(e)

            self.__best_metric = 0.0
            running_loss = torch.Tensor([0.0])
            train_loss = 0.0
            data_len = 0

            init_time = time()

            for i, data in enumerate(train_loader):
                self.on_batch_start(e, i)

                self.__train_func__(data,optimizer,loss_fn,train_metrics,running_loss,e,i)
                data_len += data[0].size(0)
                train_loss = running_loss.item()/data_len
                self.loss_history.append(train_loss)
                self.on_batch_end(e, i, train_metrics, train_loss)

            duration = time() - init_time

            if lr_schedule is not None:
                lr = lr_schedule(e)
                adjust_learning_rate(lr,optimizer)

            model_file = os.path.join(models_all, "model_{}.pth".format(e))
            self.save_model(model_file)

            print("Epoch: {}, Duration: {} , Train Loss: {}".format(e, duration, train_loss))

            if test_loader is not None:
                message = "Accuracy did not improve"
                current_best = self.__best_metric
                self.evaluate(test_loader,test_metrics)
                result = test_metrics[0].getValue()
                if result > current_best:
                    self.__best_metric = result
                    message = "{} improved from {} to {}".format(test_metrics[0].name,current_best, result)
                    model_file = os.path.join(models_best,"model_{}.pth".format(e))
                    self.save_model(model_file)

                    print("{} New Best Model saved in {}".format(message,model_file))
                else:
                    print(message)

                for metric in test_metrics:
                    print("Test {} : {}".format(metric.name,metric.getValue()))

            for metric in train_metrics:
                print("Train {} : {}".format(metric.name, metric.getValue()))

            self.on_epoch_end(e, train_metrics, test_metrics, train_loss, duration)

    def __train_func__(self,data,optimizer,loss_fn,train_metrics,running_loss,epoch,batch_num):
        raise NotImplementedError()


    def evaluate(self, test_loader, metrics):

        self.model.eval()
        for metric in metrics:
            metric.reset()

        for i, data in enumerate(test_loader):
            self.__eval_function__(data,metrics)


    def __eval_function__(self,data,metrics):
        raise NotImplementedError()

    def predict(self, inputs,apply_softmax=True):
        self.model.eval()

        if isinstance(inputs, DataLoader):
            predictions = []
            for i, data in enumerate(inputs):
                pred = self.__predict_func__(data)
                if apply_softmax:
                    pred = torch.nn.Softmax(dim=1)(pred)
                predictions.append(pred)
            return predictions
        else:
            pred = self.__predict_func__(inputs)
            if apply_softmax:
                pred = torch.nn.Softmax(dim=1)(pred)
            return pred

    def summary(self,input_size):

        input = torch.randn(input_size)

        input = input.unsqueeze(0)
        if self.cuda:
            input = input.cuda()
        input = Variable(input)

        summary = []
        ModuleDetails = namedtuple("Layer", ["name", "input_size", "output_size", "num_parameters", "multiply_adds"])
        hooks = []
        def add_hooks(module):

            def hook(module, input, output):

                # print("MODULE")
                class_name = str(module.__class__.__name__)

                layer_name = class_name + "_" + str(len(summary))

                params = 0
                if hasattr(module, "weight"):
                    weight_size = module.weight.data.size()
                    weight_params = torch.prod(torch.LongTensor(list(weight_size)))
                    params += weight_params.item()

                    if hasattr(module, "bias"):
                        try:
                            bias_size = module.bias.data.size()
                            bias_params = torch.prod(torch.LongTensor(list(bias_size)))
                            params += bias_params.item()
                        except:
                            pass

                flops = "Not Available"
                if isinstance(module, nn.Conv2d) or isinstance(module, nn.ConvTranspose2d):
                    flops = (
                    torch.prod(torch.LongTensor(list(module.weight.data.size()))) * output.size(2) * output.size(
                        3)).item()

                if isinstance(module, nn.Linear):
                    flops = (torch.prod(torch.LongTensor(list(output.size()))) * input[0].size(1)).item()

                summary.append(
                    ModuleDetails(name=layer_name, input_size=list(input[0].size()), output_size=list(output.size()),
                                  num_parameters=params, multiply_adds=flops))

            if not isinstance(module, nn.ModuleList) and not isinstance(module, nn.Sequential) and module != self.model:
                hooks.append(module.register_forward_hook(hook))

        self.model.apply(add_hooks)

        space_len = len("                             ")

        self.model(input)
        for hook in hooks:
            hook.remove()

        details = "Model Summary" + os.linesep + "Name{}Input Size{}Output Size{}Parameters{}Multiply Adds (Flops){}".format(
            ' ' * (space_len - len("Name")), ' ' * (space_len - len("Input Size")),
            ' ' * (space_len - len("Output Size")), ' ' * (space_len - len("Parameters")),
            ' ' * (space_len - len("Multiply Adds (Flops)"))) + os.linesep
        params_sum = 0
        flops_sum = 0
        for layer in summary:
            params_sum += layer.num_parameters
            if layer.multiply_adds != "Not Available":
                flops_sum += layer.multiply_adds
            details += "{}{}{}{}{}{}{}{}{}{}".format(layer.name, ' ' * (space_len - len(layer.name)), layer.input_size,
                                                     ' ' * (space_len - len(str(layer.input_size))), layer.output_size,
                                                     ' ' * (space_len - len(str(layer.output_size))),
                                                     layer.num_parameters,
                                                     ' ' * (space_len - len(str(layer.num_parameters))),
                                                     layer.multiply_adds,
                                                     ' ' * (space_len - len(str(layer.multiply_adds)))) + os.linesep

        details += os.linesep + "Total Parameters: {}".format(params_sum) + os.linesep
        details += "Total Multiply Adds (For Convolution aand Linear Layers only): {}".format(flops_sum)

        return details

    def __predict_func__(self,input):
        raise NotImplementedError()

    def on_epoch_start(self, epoch):
        pass

    def on_epoch_end(self, epoch,train_metrics,test_metrics, train_loss,duration):
        pass

    def on_batch_start(self, epoch, batch_num):
        pass

    def on_batch_end(self, epoch, batch_num, train_metrics, train_loss):
        pass

    def on_training_completed(self, train_metrics,test_metrics,  train_loss):
        pass


class StandardModel(BaseModel):
    def __init__(self,model,use_cuda_if_available=True):
        super(StandardModel,self).__init__(model,use_cuda_if_available)

    def __train_func__(self,data,optimizer,loss_fn,train_metrics,running_loss,epoch,batch_num):

        optimizer.zero_grad()

        train_x, train_y = data

        batch_size = train_x.size(0)
        if self.cuda:
            train_x = train_x.cuda()
            train_y = train_y.cuda()
        train_x = Variable(train_x)
        train_y = Variable(train_y)
        outputs = self.model(train_x)
        loss = loss_fn(outputs, train_y)
        loss.backward()

        optimizer.step()
        running_loss.add_(loss.cpu() * batch_size)

        for metric in train_metrics:
            metric.update(outputs.cpu().data, train_y.cpu().data)

    def __eval_function__(self,data,metrics):

        test_x, test_y = data
        if self.cuda:
            test_x = test_x.cuda()
            test_y = test_y.cuda()
        test_x = Variable(test_x)
        test_y = Variable(test_y)

        outputs = self.model(test_x)

        for metric in metrics:
            metric.update(outputs.cpu().data, test_y.cpu().data)

    def __predict_func__(self,inputs):
        if self.cuda:
            inputs = inputs.cuda()
        inputs = Variable(inputs)

        output = self.model(inputs)

        return output


















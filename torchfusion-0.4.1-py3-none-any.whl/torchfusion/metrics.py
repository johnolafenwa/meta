import torch

class Metric():
    def __init__(self,name):
        self.name = name
        self.__count__ = 0
        self.__sum__ = 0.0
        self.__history__ = []

    def reset(self):
        self.__count__ = 0
        self.__sum__ = 0.0

    def update(self,prediction,target):
        val = self.compute(prediction,target)
        self.__sum__ = self.__sum__ + val
        self.__count__ = self.__count__ + target.size(0)
        self.__history__.append(val)

    def getValue(self):
        return (self.__sum__.float()/self.__count__).item()


    def compute(self,prediction,label):
        raise NotImplementedError()


class Accuracy(Metric):
    def __init__(self,name,topK=1):
        super(Accuracy,self).__init__(name)
        self.topK = topK

    def compute(self,prediction,label):
        _, pred = torch.max(prediction, 1)

        correct = torch.sum(pred == label)
        return correct


class MSE(Metric):
    def __init__(self,name):
        super(MSE,self).__init__(name)

    def compute(self,prediction,label):
        _, pred = torch.max(prediction,1)
        return torch.sum((pred - label) ** 2)

from zipfile import ZipFile
import requests
import shutil
import os
import json
from io import open
from torchvision.datasets.lsun import LSUN
from torch.utils.data import Dataset
import warnings
from PIL import Image

def download_file(url,path,extract_path=None):

    data = requests.get(url, stream=True)
    with open(path, "wb") as file:
        shutil.copyfileobj(data.raw, file)

    del data
    if extract_path is not None:
        extractor = ZipFile(path)
        extractor.extractall(extract_path)
        extractor.close()

class LSUNSet(LSUN):
    def __init__(self,root,classes,sets,transform=None,target_transform=None,tag="latest",download=True):
        all_classes = []

        base_url = "http://lsun.cs.princeton.edu/htbin/download.cgi?tag={}".format(tag)

        for c in classes:
            for set in sets:
                class_name = "{}_{}".format(c,set)
                all_classes.append(class_name)
                data_file = root + os.path.sep + class_name + "_lmdb" + os.path.sep + "data.mdb"
                if not os.path.exists(data_file):
                    if not download:
                        warnings.warn("{} not found, you should set download=True".format(class_name))
                    else:
                        zip_file = root + os.path.sep + class_name + "_lmdb.zip"
                        download_url = "{}&category={}&set={}".format(base_url,c,set)
                        print("Downloading {}".format(class_name))
                        download_file(download_url,zip_file,root)
                        print("{} Downloaded and Extracted".format(class_name))

        super(LSUNSet,self).__init__(root,classes=all_classes,transform=transform,target_transform=target_transform)

""" ImageDataset optimized for loading images for inference
    Arguments:
        image_paths: an array of image or/and folder paths. You can easily mix folders and files paths
         to be jointly loaded
        recursive: if True, folders would be transversed recursively
        allowed_exts: an array of allowed image extensions

"""

class ImagesFromPaths(Dataset):
    def __init__(self,image_paths,transformations,recursive=True,allowed_exts=["jpg","png","jpeg","tif"]):
        super(ImagesFromPaths).__init__()
        assert isinstance(image_paths,list)

        self.transformations = transformations

        self.image_array = []

        for path in image_paths:


            if os.path.exists(path) == False:
                path = os.path.join(os.getcwd(),path)

            if os.path.isdir(path):

                if recursive:
                    for root, dirs, files in os.walk(path):
                        for fname in files:
                            fpath = os.path.join(root,fname)

                            if self.__get_extension(fpath) in allowed_exts:
                                self.image_array.append(fpath)
                else:
                    for fpath in os.listdir(path):
                        fpath = os.path.join(path,fpath)
                        if self.__get_extension(fpath) in allowed_exts:
                            self.image_array.append(fpath)

            elif os.path.isfile(path):
                if self.__get_extension(path) in allowed_exts:
                    self.image_array.append(path)

    def __get_extension(self,fpath):
        split = fpath.split(".")
        return split[len(split) - 1]

    def __getitem__(self, index):

        img = Image.open(self.image_array[index]).convert("RGB")
        img = self.transformations(img)

        return img

    def __len__(self):
        return len(self.image_array)

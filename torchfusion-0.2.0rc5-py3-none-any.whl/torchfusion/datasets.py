from zipfile import ZipFile
import requests
import shutil
import os
import json
from io import open
from torchvision.datasets.lsun import LSUN
from torch.utils.data import Dataset
import warnings
from PIL import Image
import tarfile
import torchvision.transforms.transforms as transforms

def download_file(url,path,extract_path=None):

    data = requests.get(url, stream=True)
    with open(path, "wb") as file:
        shutil.copyfileobj(data.raw, file)

    del data
    if extract_path is not None:
        if path.endswith(".gz") or path.endswith(".tgz") :
            extract_tar(path,extract_path)
        else:
            extract_zip(path, extract_path)




def extract_zip(source_path,extract_path):
    extractor = ZipFile(source_path)
    extractor.extractall(extract_path)
    extractor.close()

def extract_tar(source_path,extract_path):
    with tarfile.open(source_path) as tar:
        tar.extractall(extract_path)

"""Creates a dataset containing all images present in the paths specified in the image_paths array
      Arguments:
            image_paths: An array of paths, you can mix folders and files, relative and absolute paths
            transformations: A set of transformations to be applied per image
            recursive: causes the paths to be transvered recursively
            allowed_exts: an array of allowed image extensions
"""

class ImagesFromPaths(Dataset):
    def __init__(self,image_paths,transformations=None,recursive=True,allowed_exts=["jpg","png","jpeg","tif"]):
        super(ImagesFromPaths).__init__()
        assert isinstance(image_paths,list)

        self.transformations = transformations

        self.image_array = []

        for path in image_paths:


            if os.path.exists(path) == False:
                path = os.path.join(os.getcwd(),path)

            if os.path.isdir(path):

                if recursive:
                    for root, dirs, files in os.walk(path):
                        for fname in files:
                            fpath = os.path.join(root,fname)

                            if self.__get_extension(fpath) in allowed_exts:
                                self.image_array.append(fpath)
                else:
                    for fpath in os.listdir(path):
                        fpath = os.path.join(path,fpath)
                        if self.__get_extension(fpath) in allowed_exts:
                            self.image_array.append(fpath)

            elif os.path.isfile(path):
                if self.__get_extension(path) in allowed_exts:
                    self.image_array.append(path)

    def __get_extension(self,fpath):
        split = fpath.split(".")
        return split[len(split) - 1]

    def __getitem__(self, index):

        img = Image.open(self.image_array[index]).convert("RGB")

        if self.transformations is not None:
            img = self.transformations(img)

        return img

    def __len__(self):
        return len(self.image_array)

class CMPFacades(Dataset):
    def __init__(self,root,source_transforms=None,target_transforms=None,set="train",download=False,reverse_mode=False):
        super(CMPFacades,self).__init__()

        if set not in ["train","test","val"]:
            raise ValueError("Invalid set {}, must be train,test or val".format(set))

        self.images_ = []
        self.reverse_mode = reverse_mode

        self.source_transforms = source_transforms
        self.target_transforms = target_transforms

        path = os.path.join(root,"{}".format("facades",set))

        if os.path.exists(path) == False:
            if download:
                download_path = os.path.join(root,"facades.tar.gz")
                download_file("https://people.eecs.berkeley.edu/~tinghuiz/projects/pix2pix/datasets/facades.tar.gz",download_path,extract_path=root)
            else:
                raise ValueError("Facades dataset not found, set download=True to download it")
        path = os.path.join(path,set)
        for img_path in os.listdir(path):
            file_ext = self.__get_extension(img_path)
            if file_ext == "jpg":
                self.images_.append(os.path.join(path,img_path))


    def __get_extension(self, fpath):
        split = fpath.split(".")
        return split[len(split) - 1]

    def __len__(self):
        return len(self.images_)


    def __getitem__(self, index):
        img = Image.open(self.images_[index]).convert("RGB")

        if self.reverse_mode:
            img_x = img.crop((0, 0, 256, 256))
            img_y = img.crop((256, 0, 512, 256))
        else:
            img_y = img.crop((0, 0, 256, 256))
            img_x = img.crop((256, 0, 512, 256))


        if self.source_transforms is not None:
            img_x = self.source_transforms(img_x)
        if self.target_transforms is not None:
            img_y = self.target_transforms(img_y)

        return img_x,img_y

def transformations(transformations=None,mean=(0.5,0.5,0.5),std=(0.5,0.5,0.5)):
    transformations_ = []
    if transformations is not None:
        transformations_ = transformations


    #transformations_.append(transforms.ToTensor())
    #transformations_.append(transforms.Normalize(mean,std))
    #print(transformations_)
    trans = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(mean, std)

    ])

    return trans





import torch.nn as nn
import torch
import torch.nn.functional as F



class DepthwiseConvTranspose1d(nn.ConvTranspose1d):
    def __init__(self, in_channels, kernel_size, stride=1, padding=0, dilation=1, bias=True):
        super(DepthwiseConvTranspose1d, self).__init__(in_channels, in_channels, kernel_size=kernel_size, stride=stride,
                                              padding=padding, dilation=dilation, groups=in_channels, bias=bias)


class DepthwiseConv1d(nn.Conv1d):
    def __init__(self, in_channels, kernel_size, stride=1, padding=0, dilation=1, bias=True):
        super(DepthwiseConv1d, self).__init__(in_channels, in_channels, kernel_size=kernel_size, stride=stride,
                                              padding=padding, dilation=dilation, groups=in_channels, bias=bias)



class DepthwiseConv2d(nn.Conv2d):
    def __init__(self,in_channels,kernel_size,stride=1,padding=0,dilation=1,bias=True):
        super(DepthwiseConv2d,self).__init__(in_channels,in_channels,kernel_size=kernel_size,stride=stride,
                                             padding=padding,dilation=dilation,groups=in_channels,bias=bias)

class DepthwiseConv3d(nn.Conv3d):
    def __init__(self, in_channels, kernel_size, stride=1, padding=0, dilation=1, bias=True):
        super(DepthwiseConv3d, self).__init__(in_channels, in_channels, kernel_size=kernel_size, stride=stride,
                                              padding=padding, dilation=dilation, groups=in_channels, bias=bias)



class DepthwiseConvTranspose2d(nn.ConvTranspose2d):
    def __init__(self,in_channels,kernel_size,stride=1,padding=0,dilation=1,bias=True):
        super(DepthwiseConvTranspose2d,self).__init__(in_channels,in_channels,kernel_size=kernel_size,stride=stride,
                                             padding=padding,dilation=dilation,groups=in_channels,bias=bias)


class DepthwiseConvTranspose3d(nn.ConvTranspose3d):
    def __init__(self, in_channels, kernel_size, stride=1, padding=0, dilation=1, bias=True):
        super(DepthwiseConvTranspose3d, self).__init__(in_channels, in_channels, kernel_size=kernel_size, stride=stride,
                                              padding=padding, dilation=dilation, groups=in_channels, bias=bias)



class Flatten(nn.Module):
    def __init__(self):
        super(Flatten,self).__init__()

    def forward(self,inputs):
        size = torch.prod(torch.LongTensor(list(inputs.size())[1:])).item()

        return inputs.view((-1,size))

class Reshape(nn.Module):
    def __init__(self,output_shape):
        super(Reshape,self).__init__()

        self.output_shape = output_shape

    def forward(self,inputs):
        if isinstance(self.output_shape,int):
            size = [self.output_shape]
        else:
            size = list(self.output_shape)

        input_total_size = torch.prod(torch.LongTensor(list(inputs.size())[1:])).item()
        target_total_size = torch.prod(torch.LongTensor(size)).item()

        if input_total_size != target_total_size:
            raise ValueError(" Reshape must preserve total dimension, input size: {} and output size: {}".format(input.size()[1:],self.output_shape))

        size = list(size)
        size = tuple([-1] + size)
        outputs = inputs.view(size)

        return outputs


class GlobalAvgPool2d(nn.Module):
    def __init__(self):
        super(GlobalAvgPool2d,self).__init__()


    def forward(self,inputs):
        size0, size1,size2 = inputs.size(1), inputs.size(2),inputs.size(3)

        outputs = nn.AvgPool2d((size1,size2))(inputs).view(-1,size0)

        return outputs

class GlobalMaxPool2d(nn.Module):
    def __init__(self):
        super(GlobalMaxPool2d,self).__init__()


    def forward(self,inputs):
        size0, size1,size2 = inputs.size(1), inputs.size(2),inputs.size(3)

        outputs = nn.MaxPool2d((size1,size2))(inputs).view(-1,size0)

        return outputs



class GlobalAvgPool1d(nn.Module):
    def __init__(self):
        super(GlobalAvgPool1d,self).__init__()


    def forward(self,inputs):
        size0, size1 = inputs.size(1), inputs.size(2)

        outputs = nn.AvgPool1d(size1)(inputs).view(-1,size0)

        return outputs


class GlobalMaxPool1d(nn.Module):
    def __init__(self):
        super(GlobalMaxPool1d, self).__init__()

    def forward(self, inputs):
        size0, size1 = inputs.size(1), inputs.size(2)

        outputs = nn.MaxPool1d(size1)(inputs).view(-1, size0)

        return outputs



class SpectralNorm(nn.Module):
    def __init__(self, module, name='weight', power_iterations=1):
        super(SpectralNorm, self).__init__()
        self.module = module
        self.name = name
        self.power_iterations = power_iterations
        w = getattr(self.module, self.name)

        height = w.data.shape[0]
        width = w.view(height, -1).data.shape[1]

        u = nn.Parameter(w.data.new(height).normal_(0, 1), requires_grad=True)
        v = nn.Parameter(w.data.new(width).normal_(0, 1), requires_grad=True)
        u.data = self._l2normalize(u.data)
        v.data = self._l2normalize(v.data)
        w_bar = nn.Parameter(w.data)

        del self.module._parameters[self.name]

        self.module.register_parameter(self.name + "_u", u)
        self.module.register_parameter(self.name + "_v", v)
        self.module.register_parameter(self.name + "_bar", w_bar)

    def _l2normalize(self,v, eps=1e-12):
        return v / (v.norm() + eps)

    def forward(self, *args):
        u = getattr(self.module, self.name + "_u")
        v = getattr(self.module, self.name + "_v")
        w = getattr(self.module, self.name + "_bar")

        height = w.data.shape[0]
        for _ in range(self.power_iterations):
            v.data = self._l2normalize(torch.mv(torch.t(w.view(height, -1).data), u.data))
            u.data = self._l2normalize(torch.mv(w.view(height, -1).data, v.data))


        sigma = u.dot(w.view(height, -1).mv(v))
        setattr(self.module, self.name, w / sigma.expand_as(w))

        return self.module.forward(*args)



class SelfAttention(nn.Module):
    def __init__(self,in_channels):
        super(SelfAttention,self).__init__()

        self.q = nn.Conv2d(in_channels,in_channels//8,kernel_size=1)
        self.k = nn.Conv2d(in_channels,in_channels//8,kernel_size=1)

        self.v = nn.Conv2d(in_channels,in_channels,kernel_size=1)

        self.softmax = nn.Softmax(dim=-1)

        self.atten_weight = nn.Parameter(torch.tensor([0.0]))

    def forward(self,input):
        batch_size, channels, width, height = input.size()
        res = input

        queries = self.q(input).view(batch_size,-1,width*height).permute(0,2,1)
        keys = self.k(input).view(batch_size,-1,width*height)
        values = self.v(input).view(batch_size, -1, width * height)

        atten_ = self.softmax(torch.bmm(queries, keys)).permute(0,2,1)

        atten_values = torch.bmm(values,atten_).view(batch_size,channels,width,height)


        return (self.atten_weight * atten_values) + res


class SpectralNormConv2d(nn.Conv2d):
    def __init__(self,in_channels,out_channels,kernel_size,stride=1,padding=0,dilation=1,groups=1,bias=True,power_iteration=1):
        super(SpectralNormConv2d,self).__init__(in_channels,out_channels,kernel_size,stride,padding,dilation,groups,bias)
        self.register_buffer("u",torch.Tensor(1,out_channels).normal_())
        self.power_iteration = power_iteration

    def l2normalize(self,v, eps=1e-12):
        return v / (v.norm() + eps)

    @property
    def W_(self):

        w_ = self.weight.view(self.weight.size(0),-1)

        for i in range(self.power_iteration):
            _v = self.l2normalize(torch.matmul(self.u,w_.data))
            _u = self.l2normalize(torch.matmul(_v,w_.data.transpose(0,1)))

        sigma = torch.sum(F.linear(_u,w_.data.transpose(0,1)) * _v)

        self.u.copy_(_u)
        return self.weight/sigma

    def forward(self,input):
        return F.conv2d(input,self.W_,self.bias,self.stride,self.padding,self.dilation,self.groups)


class SpectralNormLinear(nn.Conv2d):
    def __init__(self,in_channels,out_channels,bias=True,power_iteration=1):
        super(SpectralNormLinear,self).__init__(in_channels,out_channels,bias)
        self.register_buffer("u",torch.Tensor(1,out_channels).normal_())
        self.power_iteration = power_iteration

    def l2normalize(self,v, eps=1e-12):
        return v / (v.norm() + eps)

    @property
    def W_(self):

        w_ = self.weight.view(self.weight.size(0),-1)

        for i in range(self.power_iteration):
            _v = self.l2normalize(torch.matmul(self.u,w_.data))
            _u = self.l2normalize(torch.matmul(_v,w_.data.transpose(0,1)))

        sigma = torch.sum(F.linear(_u,w_.data.transpose(0,1)) * _v)

        self.u.copy_(_u)
        return self.weight/sigma

    def forward(self,input):
        return F.linear(input,self.W_,self.bias)